"""Spike da T-017 — CÓDIGO DESCARTÁVEL, removido no commit de fechamento (AC-6).

Existe para produzir um número, não para virar produto. Os seis componentes
daqui são versões MÍNIMAS, com os mesmos ids dos definitivos de W3, e vivem num
registro ISOLADO: nada em `registry/componentes/` e nada em `registry/indice.py`.

Por que isolado. O registry de produção é um dicionário de módulo, e três coisas
dependem dele: `verificar_teto()` (ADR-0011), o teste de bijeção id↔view
(ADR-0017) e o índice gerado. Registrar os componentes do spike ali quebraria as
três — e os definitivos com estes mesmos ids estão sendo escritos em paralelo
por T-018, T-019 e T-024.

O que permanece depois da remoção: `docs/relatorios/R-001-medicao-modelo-real.md`
e os dados brutos ao lado dele.
"""
