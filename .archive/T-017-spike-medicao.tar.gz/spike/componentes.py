"""Os seis componentes de leitura do spike, em versão mínima.

O que é REAL aqui, porque é o que a medição mede:

    `description`, `examples` e `params` — é literalmente isto que vai ao prompt
    (ADR-0012) e ao JSON Schema do modo restrito (ADR-0024). Trocar uma palavra
    aqui muda o número medido.

O que é mínimo, porque a medição não exercita: `load` e `select`. O spike mede
COMPOSIÇÃO — da pergunta ao schema validado. Nenhum dado é carregado, nenhum
banco é tocado. Um `load` de mentira que nunca roda é honesto; um número de
mentira não é (é o erro central da POC v1, e o motivo do AC-2).
"""

import sys
from typing import Literal

from pydantic import BaseModel

from estoque.domain.identidade import UnidadeId
from estoque.domain.tipos import StatusLoteRegistrado, TipoMovimento
from estoque.registry import registry
from estoque.registry.definir import ComponentDef, LoadContext, RequiresPorValor


class Vazio(BaseModel):
    """Viewmodel de mentira. O spike não carrega dado — ver o docstring acima."""


async def _nao_carrega(params: BaseModel, ctx: LoadContext) -> Vazio:
    msg = (
        "spike da T-017: `load` não é exercitado. A medição vai da pergunta ao "
        "schema validado e para ali. Se isto foi chamado, o experimento errado "
        "está rodando."
    )
    raise NotImplementedError(msg)


def _nao_projeta(d: Vazio) -> Vazio:
    return d


# ---------------------------------------------------------------------------
class ParamsLoteLista(BaseModel):
    status: StatusLoteRegistrado | None = None
    unidade_id: UnidadeId | None = None


class ParamsLoteDetalhe(BaseModel):
    lote_id: str


class ParamsFilaVencimento(BaseModel):
    janela: Literal["30", "60", "90"] = "90"
    unidade_id: UnidadeId | None = None


class ParamsProdutoFicha(BaseModel):
    produto: str


class ParamsMovimentoLista(BaseModel):
    tipo: TipoMovimento | None = None
    lote_id: str | None = None
    unidade_id: UnidadeId | None = None


Metrica = Literal[
    "lotes_em_quarentena",
    "lotes_bloqueados",
    "lotes_vencendo_90d",
    "valor_em_estoque",
]


class ParamsEstoqueIndicador(BaseModel):
    metrica: Metrica
    unidade_id: UnidadeId | None = None


# ---------------------------------------------------------------------------
DEFINICOES: tuple[ComponentDef, ...] = (
    ComponentDef(
        id="lote_lista",
        label="Lotes",
        description=(
            "Lista os lotes em uma tabela, com produto, número, unidade, validade, "
            "status e saldo, restrita às unidades do usuário. Pode ser filtrada por "
            "status em `status` e por unidade em `unidade_id`. Use quando pedirem "
            "QUAIS lotes, uma listagem, ou os lotes de um status ou de uma unidade. "
            "NÃO use quando a resposta for uma quantidade — para isso existe "
            "`estoque_indicador`."
        ),
        examples=(
            "quais lotes estão em quarentena",
            "me liste os lotes da minha unidade",
            "liste os lotes liberados",
        ),
        params=ParamsLoteLista,
        requires="lote.ler",
        tamanho="inteira",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
    ComponentDef(
        id="lote_detalhe",
        label="Detalhe do lote",
        description=(
            "Mostra UM lote identificado em `lote_id`: produto, número, fabricação, "
            "validade, status, endereço e saldo. Use quando a pergunta citar um lote "
            "específico e pedir para abrir, ver, detalhar ou consultar esse lote. "
            "Passe em `lote_id` o identificador exatamente como aparece na pergunta."
        ),
        examples=(
            "abra o lote LT-4471",
            "quero ver o lote LT-9003 em detalhe",
            "detalhes do lote citado na nota",
        ),
        params=ParamsLoteDetalhe,
        requires="lote.ler",
        tamanho="inteira",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
    ComponentDef(
        id="fila_vencimento",
        label="Fila de vencimento",
        description=(
            "Lista os lotes que vencem dentro de uma janela de 30, 60 ou 90 dias, "
            "com saldo, validade e dias restantes, apenas das unidades do usuário. "
            "Use quando perguntarem O QUE ou QUAIS lotes estão vencendo, o que vence "
            "em breve, ou o que precisa de atenção por validade. NÃO use quando "
            "perguntarem QUANTOS — aí a resposta é um número."
        ),
        examples=(
            "o que vence nos próximos 90 dias",
            "quais lotes preciso escoar primeiro",
            "o que está vencendo na minha unidade",
        ),
        params=ParamsFilaVencimento,
        requires="lote.ler",
        tamanho="inteira",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
    ComponentDef(
        id="produto_ficha",
        label="Ficha do produto",
        description=(
            "Mostra a ficha de UM produto identificado em `produto`: nome, EAN, "
            "fabricante, princípio ativo, classe e curva ABC, com os lotes em "
            "estoque. Use quando a pergunta citar um produto pelo nome ou pelo "
            "código e pedir a ficha, o cadastro ou os dados desse produto. Passe em "
            "`produto` o nome exatamente como aparece na pergunta."
        ),
        examples=(
            "me mostre a ficha do produto Dipirona 500mg",
            "ficha do produto Amoxicilina 500mg",
            "dados cadastrais do produto",
        ),
        params=ParamsProdutoFicha,
        requires="produto.ler",
        tamanho="inteira",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
    ComponentDef(
        id="movimento_lista",
        label="Movimentações",
        description=(
            "Lista as movimentações de estoque — entrada, saída, descarte e estorno "
            "— com data, tipo, quantidade, motivo e autor, restrita às unidades do "
            "usuário. Filtra por tipo em `tipo`, por lote em `lote_id` e por unidade "
            "em `unidade_id`. Use quando perguntarem o que foi movimentado, quais "
            "saídas, entradas, descartes ou estornos houve, ou o histórico de um lote."
        ),
        examples=(
            "quais saídas foram registradas",
            "me mostre todos os estornos",
            "qual foi a movimentação do lote citado",
        ),
        params=ParamsMovimentoLista,
        requires="movimento.ler",
        tamanho="inteira",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
    ComponentDef(
        id="estoque_indicador",
        label="Indicador",
        # A descrição NÃO enumera as métricas: o enum de `params` já as lista, e
        # ele é FILTRADO por permissão. Repetir em prosa vazaria para o catálogo
        # de quem não pode um valor que ele não pode propor.
        description=(
            "Mostra UM NÚMERO do estoque para a métrica escolhida em `metrica`, com "
            "a decomposição por unidade ou por faixa de urgência, sempre restrito às "
            "unidades do usuário. Use quando a resposta for uma quantidade ou um "
            "total — QUANTOS lotes, QUANTO tem, qual o total. NÃO use quando pedirem "
            "a listagem dos lotes: para isso existem `lote_lista` e `fila_vencimento`."
        ),
        examples=(
            "quantos lotes estão em quarentena",
            "quantos lotes estão bloqueados",
            "qual o total em estoque",
        ),
        params=ParamsEstoqueIndicador,
        requires=RequiresPorValor(
            base=("lote.ler",),
            por_valor={"metrica": {"valor_em_estoque": ("custo.ler",)}},
        ),
        tamanho="linha",
        load=_nao_carrega,
        select=_nao_projeta,
    ),
)


def registrar_isolado() -> None:
    """Registra os seis NUM PROCESSO QUE NÃO TEM O ÍNDICE DE PRODUÇÃO.

    A guarda é o ponto: se `registry.indice` já foi importado, os componentes de
    produção estão no registro e registrar por cima quebraria `verificar_teto()`
    e a bijeção id↔view. Nesse caso o certo é falhar, não improvisar.
    """
    if "estoque.registry.indice" in sys.modules:
        msg = (
            "o índice de produção já está importado neste processo. O spike da "
            "T-017 usa um registro isolado de propósito — ver o docstring do "
            "pacote. Rode `python -m estoque.spike.medir` num processo limpo."
        )
        raise RuntimeError(msg)
    registry.limpar_registro()
    for d in DEFINICOES:
        registry.registrar(d)
