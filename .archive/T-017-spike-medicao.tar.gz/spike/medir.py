"""Runner do spike T-017. Roda as 30 perguntas congeladas, nos dois modelos.

    python -m estoque.spike.medir --saida <arquivo.json>

Lê as perguntas de `docs/relatorios/R-001-perguntas.json` — o arquivo do commit
ANTERIOR (AC-1). Não há perguntas dentro deste módulo de propósito: se
estivessem aqui, nada impediria ajustá-las depois de ver o resultado.

AC-2: usa `criar_adaptador()`, a fábrica real, com a chave do `.env`. O trace de
cada execução carrega origem, modelo, provedor que de fato serviu, modo efetivo,
tokens e custo relatado pelo provedor. Execução com origem `mock` é recusada.
"""

import argparse
import asyncio
import json
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from estoque.assistant.adapter import ErroDeModelo, extrair_json
from estoque.assistant.fabrica import criar_adaptador
from estoque.assistant.trace import Modo
from estoque.domain.identidade import PERMISSOES_POR_PAPEL, Ator, PapelId, UnidadeId
from estoque.registry.registry import catalogo_de
from estoque.schema.validar import validar_schema
from estoque.spike.componentes import DEFINICOES, registrar_isolado

TODAS: frozenset[UnidadeId] = frozenset({"cd-matriz", "cd-refrigerado", "filial-uberlandia"})

# Mesma tabela da suíte de avaliação (`estoque/eval/__main__.py`). Duplicada de
# propósito: importar aquele módulo traria `registry.indice` junto e derrubaria
# o isolamento do registro do spike.
PERSONAS: dict[str, tuple[PapelId, frozenset[UnidadeId]]] = {
    "marco": ("diretor", TODAS),
    "helena": ("rt", TODAS),
    "ivo": ("gerente", frozenset({"cd-matriz", "cd-refrigerado"})),
    "odair": ("gerente", frozenset({"filial-uberlandia"})),
    "cleide": ("conferente", frozenset({"cd-matriz", "cd-refrigerado"})),
    "rafael": ("comprador", TODAS),
    "sandra": ("auditoria", TODAS),
}

RAIZ = Path(__file__).resolve().parents[4]
PERGUNTAS = RAIZ / "docs" / "relatorios" / "R-001-perguntas.json"


def ator_de(nome: str) -> Ator:
    papel, unidades = PERSONAS[nome]
    return Ator(
        id=f"u-{nome}",
        nome=nome.title(),
        papel=papel,
        unidades=unidades,
        permissoes=PERMISSOES_POR_PAPEL[papel],
        ativo=True,
    )


@dataclass(frozen=True, slots=True)
class Pergunta:
    id: str
    persona: str
    texto: str
    esperado: frozenset[str]
    porque: str


def carregar_perguntas() -> tuple[Pergunta, ...]:
    dados = json.loads(PERGUNTAS.read_text(encoding="utf-8"))
    return tuple(
        Pergunta(
            id=str(p["id"]),
            persona=str(p["persona"]),
            texto=str(p["pergunta"]),
            esperado=frozenset(str(x) for x in p["esperado"]),
            porque=str(p.get("porque", "")),
        )
        for p in dados["perguntas"]
    )


@dataclass(slots=True)
class Registro:
    """Uma execução, inteira. É isto que sobrevive à remoção do spike (AC-6)."""

    pergunta_id: str
    persona: str
    pergunta: str
    modelo: str
    modo_pedido: str
    esperado: list[str] = field(default_factory=list)
    obtido: list[str] = field(default_factory=list)
    params_emitidos: list[dict[str, Any]] = field(default_factory=list)
    schema_valido: bool = False
    composicao_correta: bool = False
    motivo_da_falha: str = ""
    trace: dict[str, Any] = field(default_factory=dict)
    resposta_bruta: str = ""


def _motivo(rejeitados: list[tuple[str, str]], erro: str | None) -> str:
    if erro:
        return f"erro de transporte/provedor: {erro}"
    if rejeitados:
        return "; ".join(f"{t}: {m}" for t, m in rejeitados)
    return ""


async def uma(p: Pergunta, modelo: str, modo: Modo) -> Registro:
    ator = ator_de(p.persona)
    cat = catalogo_de(ator)
    adaptador = criar_adaptador(modelo=modelo)
    if type(adaptador).__name__ == "AdaptadorMock":
        msg = "recuso rodar com o mock — AC-2. Foi assim que a POC v1 publicou ficção."
        raise ErroDeModelo(msg)

    inicio = time.perf_counter()
    r = await adaptador.compor(p.texto, list(cat), modo=modo)
    ms = int((time.perf_counter() - inicio) * 1000)

    reg = Registro(
        pergunta_id=p.id,
        persona=p.persona,
        pergunta=p.texto,
        modelo=modelo,
        modo_pedido=modo,
        esperado=sorted(p.esperado),
        resposta_bruta=r.bruto,
    )

    obtido: frozenset[str] = frozenset()
    if not r.trace.erro:
        try:
            bruto = extrair_json(r.bruto)
        except (ValueError, json.JSONDecodeError) as e:
            r.trace.rejeitados.append(("<json>", f"resposta não é JSON: {type(e).__name__}"))
            bruto = None
        if bruto is not None:
            v = validar_schema(bruto, ator)
            # Composição vazia é schema VÁLIDO: é a resposta certa para pergunta
            # fora do catálogo, e o prompt pede exatamente isso.
            reg.schema_valido = v.ok
            obtido = frozenset(v.aceitos)
            r.trace.aceitos = v.aceitos
            r.trace.rejeitados.extend((x.tipo, x.motivo) for x in v.rejeitados)
            if v.schema is not None:
                reg.params_emitidos = [
                    {"tipo": b.tipo, "params": dict(b.params)} for b in v.schema.blocos
                ]

    reg.obtido = sorted(obtido)
    reg.composicao_correta = obtido == p.esperado
    reg.motivo_da_falha = _motivo(r.trace.rejeitados, r.trace.erro)
    resumo = r.trace.resumo()
    resumo["ms_medido_pelo_runner"] = ms
    resumo["catalogo_do_ator"] = len(cat)
    reg.trace = resumo
    return reg


def percentil(valores: list[int], q: float) -> int:
    if not valores:
        return 0
    ordenados = sorted(valores)
    i = min(len(ordenados) - 1, int(q * len(ordenados)))
    return ordenados[i]


def resumir(rs: list[Registro], modelo: str, modo: str) -> dict[str, Any]:
    sel = [r for r in rs if r.modelo == modelo and r.modo_pedido == modo]
    if not sel:
        return {}
    n = len(sel)
    validos = [r for r in sel if r.schema_valido]
    tempos = [int(r.trace.get("ms_total", 0)) for r in sel]
    entrada = [int(r.trace.get("tokens_entrada", 0)) for r in sel]
    custo = sum(float(r.trace.get("custo_usd") or 0.0) for r in sel)
    modos_efetivos = sorted({str(r.trace.get("modo_efetivo", "")) for r in sel})
    return {
        "modelo": modelo,
        "modo_pedido": modo,
        "modo_efetivo": modos_efetivos,
        "casos": n,
        "schema_valido": round(len(validos) / n, 4),
        # PRD §9: composição correta é medida DADO schema válido.
        "composicao_correta_dado_valido": (
            round(sum(r.composicao_correta for r in validos) / len(validos), 4)
            if validos
            else None
        ),
        "composicao_correta_sobre_o_total": round(
            sum(r.composicao_correta for r in sel) / n, 4
        ),
        "ms_p50": percentil(tempos, 0.50),
        "ms_p95": percentil(tempos, 0.95),
        "tokens_entrada_medio": round(sum(entrada) / n),
        "tokens_entrada_max": max(entrada),
        "custo_usd_total": round(custo, 6),
    }


async def principal(saida: Path, modelos: list[str], modos: list[Modo]) -> int:
    registrar_isolado()
    perguntas = carregar_perguntas()
    print(f"{len(perguntas)} perguntas · modelos {modelos} · modos {modos}", file=sys.stderr)

    catalogos = {
        nome: [{k: v for k, v in e.items() if k != "label"} for e in catalogo_de(ator_de(nome))]
        for nome in PERSONAS
    }

    rs: list[Registro] = []
    for modelo in modelos:
        for modo in modos:
            print(f"\n── {modelo} · {modo} ──", file=sys.stderr)
            for p in perguntas:
                r = await uma(p, modelo, modo)
                rs.append(r)
                marca = "ok " if r.composicao_correta else "ERR"
                print(
                    f"  {marca} {p.id:22} {r.trace.get('ms_total', 0):>6}ms  "
                    f"{', '.join(r.obtido) or '(não compôs)'}"
                    + ("" if r.composicao_correta else f"   ≠ {', '.join(r.esperado) or '∅'}"),
                    file=sys.stderr,
                )

    resumos = [resumir(rs, m, o) for m in modelos for o in modos]
    relatorio: dict[str, Any] = {
        "versao": 1,
        "tarefa": "T-017",
        "provedor": os.environ.get("PROVEDOR", ""),
        "perguntas_de": str(PERGUNTAS.relative_to(RAIZ)),
        "componentes_do_spike": [d.id for d in DEFINICOES],
        "catalogo_por_persona": catalogos,
        "resumos": resumos,
        "execucoes": [
            {
                "pergunta_id": r.pergunta_id,
                "persona": r.persona,
                "pergunta": r.pergunta,
                "modelo": r.modelo,
                "modo_pedido": r.modo_pedido,
                "esperado": r.esperado,
                "obtido": r.obtido,
                "params_emitidos": r.params_emitidos,
                "schema_valido": r.schema_valido,
                "composicao_correta": r.composicao_correta,
                "motivo_da_falha": r.motivo_da_falha,
                "trace": r.trace,
                "resposta_bruta": r.resposta_bruta,
            }
            for r in rs
        ],
    }
    saida.write_text(
        json.dumps(relatorio, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print("\n" + json.dumps(resumos, indent=2, ensure_ascii=False))
    print(f"\nbruto em {saida}", file=sys.stderr)
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description="Spike de medição T-017")
    p.add_argument("--saida", required=True, type=Path)
    p.add_argument("--modo", action="append", choices=["restrito", "ferramenta", "livre"])
    p.add_argument("--modelo", action="append")
    a = p.parse_args()
    modelos: list[str] = a.modelo or [
        os.environ.get("MODELO_ASSISTENTE", ""),
        os.environ.get("MODELO_ALTERNATIVO", ""),
    ]
    if not all(modelos):
        msg = "MODELO_ASSISTENTE e MODELO_ALTERNATIVO precisam estar no ambiente."
        raise ErroDeModelo(msg)
    modos: list[Modo] = a.modo or ["restrito", "livre"]
    return asyncio.run(principal(a.saida, modelos, modos))


if __name__ == "__main__":
    raise SystemExit(main())
