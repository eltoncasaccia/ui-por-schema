# UI Generativa por Schema — POC

Teste de uma hipótese: **dá para ter uma IA compondo a interface em tempo real,
como o Claude faz, sem deixá-la escrever código?**

O Claude gera código React arbitrário e o roda num iframe isolado — nem a
Anthropic confia nesse código. Para software profissional, com dados reais e
permissões, o caminho é outro: o modelo emite ~60 tokens de JSON dizendo *quais
componentes registrados compor*, o sistema valida e renderiza com os componentes
da casa.

> O modelo escolhe a composição. Nunca o código, nunca os dados, nunca a autorização.

**Leia [FINDINGS.md](./FINDINGS.md) antes de decidir qualquer coisa** — inclusive
o que esta POC ainda *não* respondeu.

## Rodando

```bash
npm install
npm run dev          # http://localhost:5173 — funciona sem API key, no adaptador mock
npm run verify       # typecheck + regras de arquitetura + smoke + render
```

Para o caminho do modelo real:

```bash
echo 'ANTHROPIC_API_KEY=sk-ant-...' > .env
npm run dev          # troque para "Claude (API real)" no painel do assistente
```

`ANTHROPIC_MODEL` também é lido do `.env` (padrão `claude-sonnet-5`; use
`claude-haiku-4-5-20251001` para medir o melhor caso de latência).

## O fluxo

```
pergunta do usuário
      ↓
AssistantAdapter          mock (local) ou Claude (tool use + streaming)
      ↓  streaming de JSON parcial
validate.ts               gate: componente não registrado é rejeitado aqui
      ↓
pipeline.ts               carrega os dados FORA do React, em paralelo
      ↓
CompositionView           schema → React, sem buscar nada
```

O mesmo pipeline atende o menu lateral. A única diferença é quem escreveu o
schema: um desenvolvedor (`src/schema/presets.ts`) ou o modelo. Essa simetria é
proposital — o modelo não é um caso especial.

## Estrutura

```
src/
  domain/        tipos + regras puras (canStart, isDelayed). Sem React, sem I/O
  data/          repository — a única porta para os dados, com latência simulada
  application/   queries, commands, pipeline, actions — toda a orquestração
  state/         store observável fora do React; persistent / session / ui separados
  registry/      defineComponent + registry + catálogo derivado para o modelo
  schema/        o contrato que o modelo pode produzir + a validação Zod
  render/        schema → React (CompositionView, Layout, ErrorBoundary)
  viewmodels/    projeções puras do domínio para a tela
  components/    apresentação. Não busca dado, não decide regra, não lê store
  shell/         ActivityBar, painéis, Workspace, Debug
server/          endpoint do Claude, como middleware do Vite (a API key fica aqui)
scripts/         arch-check, smoke, render-check
```

## O que verificar

Abra o painel **Arquitetura** (ícone `⌥` na barra lateral):

| Aba | O que mostra |
|---|---|
| Execution Trace | cada etapa e seu tempo; `validation` mostra aceitos vs. rejeitados |
| View Schema | tudo que o assistente pode produzir. Sem JSX, sem CSS, sem dados |
| Catálogo | o que o modelo enxerga — derivado do registry, não escrito à mão |
| Estado | as três categorias de estado, separadas |

Coisas que valem testar à mão:

- Clique uma viagem no menu e peça a mesma pelo assistente — mesmo pipeline.
- Peça *"compare a viagem 45872 com a 45873"*: uma composição que ninguém
  pré-montou.
- Peça *"liste as viagens programadas"*: o filtro precisa existir no catálogo
  para o recorte acontecer (ver achado 6 em FINDINGS).
- Peça a capital da Mongólia: degrada com mensagem, não quebra.
- Uma resposta do assistente fica **na conversa**; só vai para o workspace com
  "Enviar para workspace". Perguntar nunca apaga o que você estava vendo.
- Fixe com ★, saia da tela e volte: a estrela continua marcada, porque o
  favorito é chaveado pelo schema e não pela renderização.

## Verificação automática

```
npm run arch:check     # falha se um componente buscar dado, usar useEffect ou ler store
npm run smoke          # o fluxo inteiro em Node, sem DOM — 10 cenários
npm run render:check   # renderiza a árvore React inteira via react-dom/server
```

`arch:check` é o que transforma a hipótese em algo verificável em vez de
aspiracional. As regras foram testadas negativamente: introduzir a violação
quebra o check.
