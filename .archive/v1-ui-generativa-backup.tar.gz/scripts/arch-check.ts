/**
 * Architecture fitness function.
 *
 * The whole hypothesis of this POC is a set of claims about where code is NOT
 * allowed to live. Claims like that decay the moment someone is in a hurry, so
 * they are checked here instead of trusted.
 *
 * Run: npm run arch:check
 */

import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'

const ROOT = process.cwd()
const SRC = join(ROOT, 'src')

interface Rule {
  name: string
  why: string
  /** Which files the rule applies to. */
  applies: (path: string) => boolean
  /** Returns a violation message, or null. */
  check: (path: string, source: string) => string[]
}

function importsOf(source: string): string[] {
  return [...source.matchAll(/from\s+['"]([^'"]+)['"]/g)].map((match) => match[1])
}

/** Type-only imports do not create runtime coupling, so they are allowed. */
function runtimeImportsOf(source: string): string[] {
  return [...source.matchAll(/(?<!import type\s)from\s+['"]([^'"]+)['"]/g)]
    .filter((match) => {
      const line = source.slice(0, match.index).split('\n').pop() ?? ''
      const statement = source.slice(source.lastIndexOf('import', match.index!), match.index!)
      return !/^import\s+type\s/.test(statement.trim()) && !line.includes('import type')
    })
    .map((match) => match[1])
}

const inDir = (dir: string) => (path: string) => path.startsWith(`src/${dir}/`)

const rules: Rule[] = [
  {
    name: 'components-do-not-fetch',
    why: 'Um componente que busca dados devolve orquestração ao React — é exatamente o que a POC testa evitar.',
    applies: inDir('components'),
    check: (_path, source) =>
      runtimeImportsOf(source)
        .filter((specifier) =>
          /(\/|^)(data|application)\//.test(specifier) || specifier.includes('repository'),
        )
        .map((specifier) => `importa "${specifier}" (camada de dados/aplicação)`),
  },
  {
    name: 'components-hold-no-business-rules',
    why: 'A resposta para "esta viagem está atrasada?" precisa ser a mesma em todo o sistema.',
    applies: inDir('components'),
    check: (_path, source) =>
      runtimeImportsOf(source)
        .filter((specifier) => specifier.includes('domain/rules'))
        .map((specifier) => `importa regra de negócio "${specifier}"`),
  },
  {
    name: 'components-read-no-store',
    why: 'Componentes registrados recebem dados resolvidos; quem lê o store é o renderer.',
    applies: inDir('components'),
    check: (_path, source) =>
      runtimeImportsOf(source)
        .filter((specifier) => /state\/(data|session|ui|config|trace)Store|state\/useStore/.test(specifier))
        .map((specifier) => `lê o store diretamente ("${specifier}")`),
  },
  {
    name: 'mock-data-has-one-door',
    why: 'Se qualquer camada importar os arrays mockados, trocar por uma API real deixa de ser uma mudança local.',
    applies: (path) => path.startsWith('src/') && !path.startsWith('src/data/'),
    check: (_path, source) =>
      importsOf(source)
        .filter((specifier) => specifier.includes('data/mock'))
        .map((specifier) => `importa fixtures diretamente ("${specifier}")`),
  },
  {
    name: 'domain-is-pure',
    why: 'O domínio precisa ser verdadeiro independentemente de React, rede ou tela.',
    applies: inDir('domain'),
    check: (_path, source) =>
      importsOf(source)
        .filter((specifier) => !specifier.startsWith('.') || /state|render|components|data/.test(specifier))
        .map((specifier) => `depende de "${specifier}"`),
  },
  {
    name: 'no-useeffect',
    why: 'A hipótese central: orquestração fora do ciclo de render. Um efeito legítimo pode ser adicionado à allowlist, mas nunca por acidente.',
    applies: (path) => path.startsWith('src/'),
    check: (_path, source) => {
      const hits = [...source.matchAll(/\buseEffect\s*\(/g)]
      return hits.map(
        (hit) => `useEffect na linha ${source.slice(0, hit.index).split('\n').length}`,
      )
    },
  },
  {
    name: 'schema-carries-no-code',
    why: 'Se o schema puder carregar markup ou estilo, o modelo volta a escrever UI.',
    applies: (path) => path.startsWith('src/schema/') || path.startsWith('src/assistant/'),
    check: (_path, source) =>
      [/dangerouslySetInnerHTML/, /\bstyle\s*:/, /className\s*:/]
        .filter((pattern) => pattern.test(source))
        .map((pattern) => `schema/assistente manipula apresentação (${pattern})`),
  },
]

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry)
    if (statSync(full).isDirectory()) walk(full, out)
    else if (/\.tsx?$/.test(entry)) out.push(full)
  }
  return out
}

const files = walk(SRC)
let failures = 0
const byRule = new Map<string, string[]>()

for (const file of files) {
  const path = relative(ROOT, file)
  const source = readFileSync(file, 'utf8')

  for (const rule of rules) {
    if (!rule.applies(path)) continue
    for (const violation of rule.check(path, source)) {
      failures += 1
      const list = byRule.get(rule.name) ?? []
      list.push(`${path}: ${violation}`)
      byRule.set(rule.name, list)
    }
  }
}

console.log(`\narch:check — ${files.length} arquivos, ${rules.length} regras\n`)

for (const rule of rules) {
  const violations = byRule.get(rule.name)
  if (!violations) {
    console.log(`  ok    ${rule.name}`)
    continue
  }
  console.log(`  FALHA ${rule.name}`)
  console.log(`        ${rule.why}`)
  for (const violation of violations) console.log(`        · ${violation}`)
}

if (failures > 0) {
  console.error(`\n${failures} violação(ões). A arquitetura não se sustenta sozinha.\n`)
  process.exit(1)
}

console.log('\nTodas as regras passaram.\n')
