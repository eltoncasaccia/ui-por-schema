/**
 * Renders the whole application to a string after driving it through the
 * application layer, to confirm React actually draws what the pipeline
 * produced. Not a substitute for looking at it, but it catches a broken tree.
 *
 * Run: npm run render:check
 */

import { renderToString } from 'react-dom/server'
import { App } from '../src/app/App'
import { ask, openPreset } from '../src/application/actions'
import { fleetOverviewSchema } from '../src/schema/presets'
import { sendToWorkspace } from '../src/application/actions'
import { sessionStore } from '../src/state/sessionStore'
import { uiActions } from '../src/state/uiStore'

let failures = 0

function expect(name: string, html: string, needle: string): void {
  if (html.includes(needle)) {
    console.log(`  ok    ${name}`)
  } else {
    failures += 1
    console.log(`  FALHA ${name} — não encontrei "${needle}"`)
  }
}

async function main() {
  console.log('\nRenderizando a aplicação\n')

  await openPreset(fleetOverviewSchema, 'Panorama da frota')
  let html = renderToString(<App />)
  expect('shell montou', html, 'activity-bar')
  expect('título do workspace', html, 'Panorama da frota')
  expect('metric cards renderizaram', html, 'metric-value')
  expect('tabela de veículos renderizou', html, 'ABC-1234')
  expect('layout grid aplicado', html, 'layout-grid')
  expect('origem do schema marcada', html, 'schema do sistema')

  await ask('mostre a viagem 45872')
  uiActions.openAssistant()
  html = renderToString(<App />)
  expect('conversa renderizou', html, 'msg-user')
  expect('composição inline na conversa', html, 'inline-composition')
  expect('resumo da viagem', html, 'Campinas → Sorocaba')
  expect('linha do tempo', html, 'timeline-item')
  expect('mapa esquemático', html, 'map-vehicle')
  expect('botão de envio ao workspace', html, 'Enviar para workspace')
  expect('botão de limpar conversa', html, '>Limpar<')

  const answer = [...sessionStore.getSnapshot().conversation]
    .reverse()
    .find((m) => m.role === 'assistant')!
  sendToWorkspace(answer.compositionId!)
  html = renderToString(<App />)
  expect('origem do assistente marcada após envio', html, 'schema do assistente')

  uiActions.toggleDebug()
  uiActions.setDebugTab('trace')
  html = renderToString(<App />)
  expect('debug abriu', html, 'Execution Trace')
  expect('trace tem passos', html, 'trace-step')
  expect('estágio data_load registrado', html, 'data_load')

  uiActions.setDebugTab('schema')
  html = renderToString(<App />)
  expect('schema exibido', html, '&quot;trip_summary&quot;')

  console.log(
    failures === 0 ? '\nA árvore React renderiza inteira.\n' : `\n${failures} falha(s).\n`,
  )
  if (failures > 0) process.exit(1)
}

void main()
