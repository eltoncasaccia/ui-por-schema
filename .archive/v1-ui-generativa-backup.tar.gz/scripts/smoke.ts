/**
 * End-to-end exercise of the application, with no React and no DOM.
 *
 * That this file runs at all is part of the result: every stage from intent to
 * resolved view state is reachable without rendering anything. If orchestration
 * lived in components, none of this could be tested this way.
 *
 * Run: npm run smoke
 */

import {
  ask,
  clearChat,
  openPinned,
  openPreset,
  openTrip,
  pin,
  sendToWorkspace,
  unpin,
  isPinned,
} from '../src/application/actions'
import { tripTrackingSchema } from '../src/schema/presets'
import { validateViewSchema } from '../src/schema/validate'
import { viewKey } from '../src/schema/types'
import { sessionStore } from '../src/state/sessionStore'
import { dataStore } from '../src/state/dataStore'
import { traceStore } from '../src/state/traceStore'
import { buildCatalog } from '../src/registry/catalog'

let failures = 0

function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok    ${name}`)
  } else {
    failures += 1
    console.log(`  FALHA ${name}${detail ? ` — ${detail}` : ''}`)
  }
}

function workspace() {
  const state = sessionStore.getSnapshot()
  return state.workspaceCompositionId
    ? state.compositions[state.workspaceCompositionId]
    : null
}

/** The composition attached to the most recent assistant message. */
function lastAnswer() {
  const state = sessionStore.getSnapshot()
  const message = [...state.conversation]
    .reverse()
    .find((entry) => entry.role === 'assistant')
  return message?.compositionId ? state.compositions[message.compositionId] : null
}

async function main() {
  console.log('\n1. Catálogo derivado do registry')
  const catalog = buildCatalog()
  check('catálogo tem componentes', catalog.length === 7, `${catalog.length}`)
  check(
    'todo componente descreve seus params',
    catalog.every((entry) => entry.params && typeof entry.params === 'object'),
  )

  console.log('\n2. Caminho de navegação (schema escrito por desenvolvedor)')
  await openPreset(tripTrackingSchema('45872'), 'Abrir viagem 45872')
  const nav = workspace()
  check('composição no workspace', nav !== null)
  check('3 componentes', nav?.nodes.length === 3, String(nav?.nodes.length))
  check(
    'todos os nós prontos',
    nav?.nodes.every((node) => node.status === 'ready') ?? false,
    JSON.stringify(nav?.nodes.map((n) => n.status)),
  )
  check('entidade carregada uma vez', dataStore.getSnapshot().trips['45872'] !== undefined)

  console.log('\n3. Caminho do assistente (schema escrito pelo modelo mock)')
  const beforeAsk = workspace()?.id ?? null
  await ask('mostre a viagem 45872')
  const chat = lastAnswer()
  check('composição veio do assistente', chat?.source === 'assistant')
  check('nós prontos', chat?.nodes.every((node) => node.status === 'ready') ?? false)
  check(
    'schema não contém código',
    JSON.stringify(chat?.schema ?? {}).match(/</) === null,
  )
  check(
    'a resposta NÃO invadiu o workspace',
    workspace()?.id === beforeAsk,
    `workspace agora é ${workspace()?.id}`,
  )

  sendToWorkspace(chat!.id)
  check('vai para o workspace só quando pedido', workspace()?.id === chat!.id)

  console.log('\n4. Composição que ninguém pré-montou (o teste decisivo do L2)')
  await ask('compare a viagem 45872 com a 45873')
  const compare = lastAnswer()
  check('4 componentes compostos', compare?.nodes.length === 4, String(compare?.nodes.length))
  check(
    'duas viagens diferentes no mesmo schema',
    new Set(compare?.nodes.map((n) => (n.params as { tripId: string }).tripId)).size === 2,
  )
  check('todos prontos', compare?.nodes.every((n) => n.status === 'ready') ?? false)

  // Contado aqui, no pico — depois `clearChat` descarta composições órfãs.
  const peakReferences = Object.values(sessionStore.getSnapshot().compositions)
    .flatMap((composition) =>
      composition.nodes
        .map((node) => (node.params as { tripId?: string }).tripId)
        .filter(Boolean),
    ).length

  console.log('\n5. Invalidação de pedido superado (o que o cleanup do useEffect faria)')
  const slow = openTrip('45872')
  const fast = openTrip('45873')
  await Promise.all([slow, fast])
  const raced = workspace()
  check(
    'o pedido mais recente vence',
    (raced?.schema.components[0]?.params as { tripId: string })?.tripId === '45873',
    JSON.stringify(raced?.schema.components[0]?.params),
  )
  check('vencedor totalmente carregado', raced?.nodes.every((n) => n.status === 'ready') ?? false)

  console.log('\n6. O registry é a fronteira de segurança')
  const attack = validateViewSchema({
    title: 'injeção',
    layout: 'stack',
    components: [
      { type: 'RandomReactComponent', params: {} },
      { type: '<script>alert(1)</script>', params: {} },
      { type: 'trip_summary', params: { tripId: '45872' } },
    ],
  })
  check('schema aceito parcialmente', attack.ok)
  check(
    'componentes não registrados rejeitados',
    attack.ok && attack.rejected.length === 2 && attack.schema.components.length === 1,
    attack.ok ? JSON.stringify(attack.rejected) : 'inválido',
  )

  const badParams = validateViewSchema({
    title: 'params inválidos',
    layout: 'stack',
    components: [{ type: 'metric_card', params: { metric: 'lucro_do_trimestre' } }],
  })
  check('valor fora do enum rejeitado', !badParams.ok)

  const badLayout = validateViewSchema({
    title: 'layout arbitrário',
    layout: 'display:grid;grid-template-columns:1fr 1fr',
    components: [{ type: 'trip_summary', params: { tripId: '45872' } }],
  })
  check('layout arbitrário rejeitado', !badLayout.ok)

  console.log('\n7. Erros são escritos para o modelo, não para um stack trace')
  await ask('mostre a viagem 99999')
  const missing = lastAnswer()
  const errorNode = missing?.nodes.find((node) => node.status === 'error')
  check('nó marcado como erro', errorNode !== undefined)
  check(
    'erro lista alternativas',
    (errorNode?.error ?? '').includes('45872'),
    errorNode?.error,
  )

  console.log('\n8. Pergunta fora do domínio degrada sem quebrar')
  await ask('qual é a capital da Mongólia')
  const conversation = sessionStore.getSnapshot().conversation
  const last = conversation[conversation.length - 1]
  check('resposta marcada com erro amigável', Boolean(last.error))
  check('workspace intacto após pergunta inválida', (workspace()?.nodes.length ?? 0) > 0)

  console.log('\n9. Filtro por status (o catálogo precisa nomear o recorte)')
  await ask('liste as viagens programadas')
  const scheduled = lastAnswer()
  const scheduledParams = scheduled?.schema.components[0]?.params as {
    entity?: string
    filter?: string
  }
  check('usou entity_table', scheduled?.schema.components[0]?.type === 'entity_table')
  check(
    'filtrou por scheduled em vez de listar tudo',
    scheduledParams?.filter === 'scheduled',
    JSON.stringify(scheduledParams),
  )

  const cancelled = validateViewSchema({
    title: 'x',
    layout: 'stack',
    components: [{ type: 'entity_table', params: { entity: 'drivers', filter: 'maintenance' } }],
  })
  check('combinação sem sentido é rejeitada no gate', !cancelled.ok)

  console.log('\n10. Favoritos são keyed pela view, não pela renderização')
  await openTrip('45872')
  const first = workspace()!
  pin(first)
  const pinsAfterFirst = sessionStore.getSnapshot().pinned.length
  check('fixou', pinsAfterFirst === 1)

  // Reabrir a mesma viagem cria uma composição nova — o favorito deve persistir.
  await openTrip('45872')
  const second = workspace()!
  check('reabrir gerou outra composição', second.id !== first.id)
  check(
    'a estrela continua marcada depois de sair e voltar',
    isPinned(second.schema),
  )

  // A estrela é um toggle: clicar numa view já fixada remove. O que não pode
  // acontecer — e era o bug — é a mesma view virar duas entradas.
  pin(second)
  check('a estrela desfixa', sessionStore.getSnapshot().pinned.length === 0)
  pin(second)
  check('e refixa', sessionStore.getSnapshot().pinned.length === 1)

  await openTrip('45872')
  const third = workspace()!
  pin(third)
  pin(third)
  const pins = sessionStore.getSnapshot().pinned
  check(
    'nunca duplica, mesmo em outra renderização da mesma view',
    pins.length === 1 && pins[0].key === viewKey(third.schema),
    `${pins.length} favoritos`,
  )

  await openPinned(pins[0])
  check(
    'reabrir favorito recarrega os dados',
    workspace()?.nodes.every((node) => node.status === 'ready') ?? false,
  )

  unpin(sessionStore.getSnapshot().pinned[0])
  check('remover dos favoritos funciona', sessionStore.getSnapshot().pinned.length === 0)

  // Duas viagens diferentes são duas views diferentes.
  await openTrip('45872')
  pin(workspace()!)
  await openTrip('45873')
  pin(workspace()!)
  check('views distintas coexistem', sessionStore.getSnapshot().pinned.length === 2)

  console.log('\n11. Limpar conversa preserva o workspace')
  const kept = workspace()!.id
  clearChat()
  check('conversa vazia', sessionStore.getSnapshot().conversation.length === 0)
  check('workspace preservado', sessionStore.getSnapshot().workspaceCompositionId === kept)
  check(
    'composições órfãs foram descartadas',
    Object.keys(sessionStore.getSnapshot().compositions).length === 1,
    `${Object.keys(sessionStore.getSnapshot().compositions).length} restantes`,
  )

  console.log('\n12. Uma entidade, uma cópia')
  const data = dataStore.getSnapshot()
  check(
    `${peakReferences} referências a viagens espalhadas pelas composições`,
    peakReferences > 5,
    String(peakReferences),
  )
  check(
    'mas apenas uma instância de cada viagem no store',
    Object.keys(data.trips).length <= 6,
    `${Object.keys(data.trips).length} viagens`,
  )

  console.log('\n13. Trace registrou tudo')
  const runs = traceStore.getSnapshot().runs
  check('execuções registradas', runs.length >= 6, String(runs.length))
  const timed = runs.filter((run) => run.timeToFirstComponentMs !== undefined)
  check('tempo até o 1º componente medido', timed.length > 0)
  if (timed.length > 0) {
    const values = timed.map((r) => Math.round(r.timeToFirstComponentMs!))
    console.log(`        TTFC (ms): ${values.join(', ')}`)
  }

  console.log(
    failures === 0
      ? '\nTodos os cenários passaram.\n'
      : `\n${failures} cenário(s) falharam.\n`,
  )
  process.exit(failures === 0 ? 1 * 0 : 1)
}

void main()
