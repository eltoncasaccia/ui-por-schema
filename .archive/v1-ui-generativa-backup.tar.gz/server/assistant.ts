/**
 * The assistant endpoint. Runs inside the Vite dev server.
 *
 * Three things worth noticing, because they are the whole security argument:
 *   1. The API key lives here and never reaches the browser.
 *   2. The model is given a catalogue of component names — not the database,
 *      not the user's session, not a way to run code.
 *   3. Its output is JSON that the client validates before anything renders.
 *      Nothing here trusts the model; the model is an author, not an authority.
 */

import Anthropic from '@anthropic-ai/sdk'
import type { Connect } from 'vite'
import type { ServerResponse } from 'node:http'

const DEFAULT_MODEL = 'claude-sonnet-5'

export interface AssistantOptions {
  apiKey?: string
  model?: string
  /** Prompt text describing the registry, generated from the app's catalogue. */
  catalog: string
  componentIds: string[]
}

function systemPrompt(options: AssistantOptions): string {
  return `Você compõe telas de um sistema de logística escolhendo componentes já existentes.

Você NÃO escreve código, HTML, CSS nem texto de dados. Você devolve apenas a
composição: um título, um layout e uma lista de componentes registrados com
seus parâmetros. Os dados são buscados pelo sistema, com as permissões do
usuário — você nunca informa valores, horários, placas ou nomes.

REGRAS
- Use somente estes componentes: ${options.componentIds.join(', ')}.
- Um componente fora dessa lista é rejeitado e a resposta falha.
- Layout: "stack" (uma coluna), "split" (os dois primeiros lado a lado) ou
  "grid" (duas colunas). Use "grid" quando houver vários metric_card.
- Prefira 2 a 4 componentes. Nunca passe de 8.
- Se a pergunta citar uma viagem, use o número exatamente como veio.
- Se a pergunta estiver fora do domínio (viagens, veículos, motoristas, rotas),
  devolve um único text_block dizendo o que o sistema cobre.

CATÁLOGO
${options.catalog}`
}

const TOOL = {
  name: 'render_view',
  description: 'Monta a tela que responde à pergunta do usuário.',
  input_schema: {
    type: 'object' as const,
    properties: {
      title: { type: 'string', description: 'Título curto da tela.' },
      layout: { type: 'string', enum: ['stack', 'split', 'grid'] },
      components: {
        type: 'array',
        minItems: 1,
        maxItems: 8,
        items: {
          type: 'object',
          properties: {
            type: { type: 'string', description: 'Id de um componente registrado.' },
            params: { type: 'object', description: 'Parâmetros do componente.' },
          },
          required: ['type', 'params'],
        },
      },
    },
    required: ['title', 'layout', 'components'],
  },
}

function send(res: ServerResponse, payload: unknown): void {
  res.write(`data: ${JSON.stringify(payload)}\n\n`)
}

async function readBody(req: Connect.IncomingMessage): Promise<string> {
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  return Buffer.concat(chunks).toString('utf8')
}

export function assistantMiddleware(options: AssistantOptions): Connect.NextHandleFunction {
  const apiKey = options.apiKey
  const model = options.model || DEFAULT_MODEL
  const client = apiKey ? new Anthropic({ apiKey }) : null

  return async (req, res, next) => {
    const url = req.url ?? ''

    if (url.startsWith('/api/assistant/health')) {
      res.setHeader('content-type', 'application/json')
      res.end(JSON.stringify({ ready: client !== null, model: client ? model : null }))
      return
    }

    if (!url.startsWith('/api/assistant') || req.method !== 'POST') {
      next()
      return
    }

    if (!client) {
      res.statusCode = 503
      res.end('ANTHROPIC_API_KEY não configurada. Rode com o adaptador mock.')
      return
    }

    let input = ''
    try {
      input = (JSON.parse(await readBody(req)) as { input?: string }).input ?? ''
    } catch {
      res.statusCode = 400
      res.end('corpo inválido')
      return
    }

    res.setHeader('content-type', 'text/event-stream')
    res.setHeader('cache-control', 'no-cache')
    res.setHeader('connection', 'keep-alive')

    try {
      const stream = client.messages.stream({
        model,
        max_tokens: 1024,
        system: systemPrompt(options),
        tools: [TOOL],
        tool_choice: { type: 'tool', name: 'render_view' },
        messages: [{ role: 'user', content: input }],
      })

      stream.on('streamEvent', (event) => {
        if (
          event.type === 'content_block_delta' &&
          event.delta.type === 'input_json_delta'
        ) {
          // Forward the tool input as it is written, so the client can render
          // components before the model has finished the rest of the answer.
          send(res, { t: 'delta', text: event.delta.partial_json })
        }
      })

      await stream.finalMessage()
    } catch (error) {
      send(res, { t: 'error', message: error instanceof Error ? error.message : String(error) })
    }

    res.end()
  }
}
