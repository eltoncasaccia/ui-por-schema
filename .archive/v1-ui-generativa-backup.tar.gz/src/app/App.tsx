import { ActivityBar } from '../shell/ActivityBar'
import { AssistantPanel } from '../shell/AssistantPanel'
import { DebugPanel } from '../shell/DebugPanel'
import { NavigationPanel } from '../shell/NavigationPanel'
import { PinnedPanel } from '../shell/PinnedPanel'
import { Workspace } from '../shell/Workspace'
import { uiStore } from '../state/uiStore'
import { useStore } from '../state/useStore'

/**
 * The Application Shell — fixed structure, adaptive contents.
 *
 * Worth noting how little is here. There is no state to lift, nothing to
 * synchronise and no effect to run: every panel reads the store it cares about.
 */
export function App() {
  const { activePanel, sidePanelOpen, assistantOpen, debugOpen } = useStore(uiStore)

  return (
    <div
      className={`shell ${sidePanelOpen ? 'has-side' : ''} ${
        assistantOpen ? 'has-assistant' : ''
      } ${debugOpen ? 'has-debug' : ''}`}
    >
      <ActivityBar />

      {sidePanelOpen && (
        <div className="side-panel">
          {activePanel === 'navigation' && <NavigationPanel />}
          {activePanel === 'pinned' && <PinnedPanel />}
        </div>
      )}

      <Workspace />

      {assistantOpen && (
        <div className="assistant-dock">
          <AssistantPanel />
        </div>
      )}

      {debugOpen && <DebugPanel />}
    </div>
  )
}
