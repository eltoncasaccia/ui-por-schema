/**
 * Every way the application can be driven, in one file.
 *
 * The UI calls these; it never calls a query, never touches the repository and
 * never assembles a schema itself. Two entry points matter: `openPreset`,
 * where a developer authored the schema, and `ask`, where a model did. They
 * converge on the same pipeline two lines later.
 */

import { claudeAssistant } from '../assistant/claudeAssistant'
import { mockAssistant } from '../assistant/mockAssistant'
import type { AssistantAdapter } from '../assistant/types'
import type { Dispatch, UiAction } from '../schema/actions'
import { tripTrackingSchema } from '../schema/presets'
import type { Composition, LayoutKind, ViewSchema } from '../schema/types'
import { viewKey } from '../schema/types'
import { validateNode, validateViewSchema } from '../schema/validate'
import { configStore } from '../state/configStore'
import { sessionActions, sessionStore, type PinnedView } from '../state/sessionStore'
import { claimSlot } from '../state/store'
import { finishRun, markFirstComponent, startRun, step } from '../state/traceStore'
import { uiActions } from '../state/uiStore'
import { getComponent } from '../registry/registry'
import { nextId, renderComposition } from './pipeline'

const WORKSPACE_SLOT = 'workspace'

function adapter(): AssistantAdapter {
  return configStore.getSnapshot().adapterId === 'claude' ? claudeAssistant : mockAssistant
}

/* ------------------------------------------------------------------ *
 * Navigation path — schema written by a developer
 * ------------------------------------------------------------------ */

export async function openPreset(schema: ViewSchema, label: string): Promise<void> {
  const runId = nextId('run')
  startRun(runId, label, 'navigation', 'preset')
  sessionActions.setIntent({ source: 'navigation', view: schema.title })

  const endValidation = step(runId, 'validation', 'Validando schema')
  const result = validateViewSchema(schema)
  if (!result.ok) {
    endValidation('error', result.errors.join(' | '))
    return
  }
  endValidation('ok', `${result.schema.components.length} componente(s) aceitos`)

  await renderComposition({
    schema: result.schema,
    source: 'navigation',
    runId,
    slot: WORKSPACE_SLOT,
    showInWorkspace: true,
  })
}

export function openTrip(tripId: string): Promise<void> {
  return openPreset(tripTrackingSchema(tripId), `Abrir viagem ${tripId}`)
}

/* ------------------------------------------------------------------ *
 * Assistant path — schema written by a model
 * ------------------------------------------------------------------ */

export async function ask(input: string): Promise<void> {
  const text = input.trim()
  if (!text) return

  const active = adapter()
  const runId = nextId('run')
  startRun(runId, text, 'assistant', active.id)
  sessionActions.setIntent({ source: 'assistant', adapter: active.id, input: text })

  sessionActions.addMessage({ id: nextId('msg'), role: 'user', text })

  const messageId = nextId('msg')
  const compositionId = nextId('composition')
  sessionActions.addMessage({
    id: messageId,
    role: 'assistant',
    text: '',
    compositionId,
    streaming: true,
  })

  const emptySchema: ViewSchema = { title: 'Compondo…', layout: 'stack', components: [] }
  const composition: Composition = {
    id: compositionId,
    title: 'Compondo…',
    layout: 'stack',
    nodes: [],
    source: 'assistant',
    schema: emptySchema,
    createdAt: Date.now(),
  }
  sessionActions.putComposition(composition)

  // The answer stays in the conversation. It reaches the workspace only if the
  // user sends it there, so asking a question never wipes what they were
  // looking at. Each message owns its own slot, so answers never race.
  const isCurrent = claimSlot(`chat:${messageId}`)

  const endAssistant = step(runId, 'assistant', `Consultando ${active.label}`)
  const endSchema = step(runId, 'schema_received', 'Recebendo schema (streaming)')

  const accepted: ViewSchema['components'] = []
  const rejected: string[] = []
  const loads: Promise<void>[] = []
  let failure: string | null = null
  let layout: LayoutKind = 'stack'
  let title = 'Resposta'
  let firstEvent = true

  try {
    for await (const event of active.ask(text)) {
      if (firstEvent) {
        endAssistant('ok')
        firstEvent = false
      }

      if (event.type === 'error') {
        failure = event.message
        break
      }

      if (event.type === 'title') {
        title = event.title
        sessionActions.updateComposition(compositionId, { title })
        continue
      }

      if (event.type === 'layout') {
        layout = event.layout
        sessionActions.updateComposition(compositionId, { layout })
        continue
      }

      if (event.type === 'note') {
        sessionActions.patchMessage(messageId, { text: event.text })
        continue
      }

      // event.type === 'node' — the gate every model output passes through.
      const check = validateNode(event.node.type, event.node.params)
      if (!check.ok) {
        rejected.push(`${event.node.type}: ${check.reason}`)
        continue
      }

      const index = accepted.length
      accepted.push({ type: event.node.type, params: check.params })
      sessionActions.appendNode(compositionId, {
        type: event.node.type,
        params: check.params,
        status: 'pending',
      })

      const definition = getComponent(event.node.type)!
      loads.push(
        definition
          .load(check.params)
          .then(() => {
            if (!isCurrent()) return
            sessionActions.patchNode(compositionId, index, { status: 'ready' })
            markFirstComponent(runId)
          })
          .catch((error: unknown) => {
            if (!isCurrent()) return
            sessionActions.patchNode(compositionId, index, {
              status: 'error',
              error: error instanceof Error ? error.message : String(error),
            })
          }),
      )
    }
  } catch (error) {
    failure = error instanceof Error ? error.message : String(error)
  }

  if (firstEvent) endAssistant('error', failure ?? 'sem resposta')
  endSchema(failure ? 'error' : 'ok', `${accepted.length} nó(s) recebidos`)

  const endValidation = step(runId, 'validation', 'Validando contra o registry')
  endValidation(
    rejected.length === 0 ? 'ok' : 'error',
    rejected.length === 0
      ? `${accepted.length} aceitos, 0 rejeitados`
      : `${accepted.length} aceitos, ${rejected.length} rejeitados — ${rejected.join(' | ')}`,
  )

  sessionActions.updateComposition(compositionId, {
    schema: { title, layout, components: accepted },
  })

  await Promise.all(loads)

  sessionActions.patchMessage(messageId, {
    streaming: false,
    error: failure ?? (accepted.length === 0 ? 'Nenhum componente pôde ser montado.' : undefined),
  })

  finishRun(runId)
}

/* ------------------------------------------------------------------ *
 * Component → application
 * ------------------------------------------------------------------ */

export const dispatch: Dispatch = (action: UiAction) => {
  if (action.type === 'open_trip') {
    void openTrip(action.tripId)
    return
  }
  if (action.type === 'ask') {
    uiActions.openAssistant()
    void ask(action.text)
  }
}

/** Promotes an assistant answer to the main workspace, on explicit request. */
export function sendToWorkspace(compositionId: string): void {
  sessionActions.showInWorkspace(compositionId)
}

export function clearChat(): void {
  sessionActions.clearConversation()
}

export function pin(composition: Composition): void {
  sessionActions.togglePin(composition.schema, composition.title)
}

export function isPinned(schema: ViewSchema): boolean {
  const key = viewKey(schema)
  return sessionStore.getSnapshot().pinned.some((entry) => entry.key === key)
}

export function unpin(entry: PinnedView): void {
  sessionActions.togglePin(entry.schema, entry.label)
}

/** Reopens a pinned view by re-running its schema, so the data is current. */
export function openPinned(entry: PinnedView): Promise<void> {
  return openPreset(entry.schema, `Reabrir ${entry.label}`)
}
