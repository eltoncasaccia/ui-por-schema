/**
 * Application start-up. Runs once, imperatively, before React mounts.
 *
 * This is the kind of work that usually ends up in a top-level `useEffect`
 * firing after first paint. There is no reason for it to wait for a render, so
 * it does not.
 */

import { openPreset } from './actions'
import { fleetOverviewSchema } from '../schema/presets'
import { listTrips } from './queries'
import { dataActions } from '../state/dataStore'
import { configActions } from '../state/configStore'
import { claudeAssistant } from '../assistant/claudeAssistant'

export function bootstrap(): void {
  void listTrips()
    .then((trips) => dataActions.ingestTrips(trips, 'allTripIds'))
    .catch((error) => console.error('[bootstrap] falha ao carregar viagens', error))

  // The app opens on a real view. An empty workspace would demonstrate nothing.
  void openPreset(fleetOverviewSchema, 'Panorama da frota')

  void claudeAssistant
    .available()
    .then(configActions.setClaudeAvailable)
    .catch(() => configActions.setClaudeAvailable(false))
}
