/**
 * Request coalescing.
 *
 * A tracking view asks for the same trip from four different components at
 * once. Without this, that is four identical round trips. Only in-flight
 * promises are shared — nothing is cached after it settles, so no one ever
 * reads a stale value.
 */

const pending = new Map<string, Promise<unknown>>()

export function coalesce<T>(key: string, run: () => Promise<T>): Promise<T> {
  const existing = pending.get(key)
  if (existing) return existing as Promise<T>

  const promise = run().finally(() => pending.delete(key))
  pending.set(key, promise)
  return promise
}
