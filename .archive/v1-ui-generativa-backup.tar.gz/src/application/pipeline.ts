/**
 * The render pipeline. Everything that happens between "a schema exists" and
 * "React has data to draw" happens here, outside React.
 *
 *   schema → composition (all nodes pending) → parallel load → nodes ready
 *
 * Because loading is driven from here rather than from a mounted component,
 * there is no effect to clean up — and therefore an explicit slot token to
 * drop results that a newer request has superseded.
 */

import { getComponent } from '../registry/registry'
import type { Composition, CompositionSource, ViewSchema } from '../schema/types'
import { sessionActions } from '../state/sessionStore'
import { claimSlot } from '../state/store'
import { finishRun, markFirstComponent, step } from '../state/traceStore'

let counter = 0
export function nextId(prefix: string): string {
  counter += 1
  return `${prefix}-${counter}`
}

export interface RenderRequest {
  schema: ViewSchema
  source: CompositionSource
  runId: string
  /**
   * Which surface this composition belongs to. The workspace is a single slot,
   * so a newer workspace render invalidates an older one; chat messages each
   * get their own slot and never fight.
   */
  slot: string
  showInWorkspace: boolean
}

export async function renderComposition(request: RenderRequest): Promise<string> {
  const { schema, source, runId, slot, showInWorkspace } = request
  const compositionId = nextId('composition')

  // Claim the slot BEFORE any awaiting, so a request issued later always wins.
  const isCurrent = claimSlot(slot)

  const composition: Composition = {
    id: compositionId,
    title: schema.title,
    layout: schema.layout,
    source,
    schema,
    createdAt: Date.now(),
    nodes: schema.components.map((node) => ({
      type: node.type,
      params: node.params,
      status: 'pending',
    })),
  }

  sessionActions.putComposition(composition)
  if (showInWorkspace) sessionActions.showInWorkspace(compositionId)

  const endLoad = step(
    runId,
    'data_load',
    `Carregando ${composition.nodes.length} componente(s)`,
  )

  const results = await Promise.all(
    composition.nodes.map(async (node, index) => {
      const definition = getComponent(node.type)
      if (!definition) return false
      try {
        await definition.load(node.params)
        if (!isCurrent()) return false
        sessionActions.patchNode(compositionId, index, { status: 'ready' })
        markFirstComponent(runId)
        return true
      } catch (error) {
        if (!isCurrent()) return false
        sessionActions.patchNode(compositionId, index, {
          status: 'error',
          error: error instanceof Error ? error.message : String(error),
        })
        return false
      }
    }),
  )

  if (!isCurrent()) {
    endLoad('ok', 'descartado — substituído por um pedido mais recente')
    return compositionId
  }

  const failed = results.filter((ok) => !ok).length
  endLoad(
    failed === 0 ? 'ok' : 'error',
    failed === 0 ? undefined : `${failed} componente(s) falharam`,
  )
  finishRun(runId)
  return compositionId
}
