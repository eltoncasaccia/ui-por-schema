/**
 * Read use-cases. Task-shaped, not resource-shaped.
 *
 * A resource API would make the caller fetch trip, then vehicle, then driver,
 * then route. Each of those round trips costs a model turn when an LLM is the
 * caller, so the application layer joins them once, here.
 */

import { repository } from '../data/repository'
import { coalesce } from './inflight'
import { isDelayed, delayMinutes } from '../domain/rules'
import type { Trip, TripTracking, Vehicle } from '../domain/types'

/** Everything the tracking screen needs, in one call. */
export function getTripTracking(tripId: string): Promise<TripTracking> {
  return coalesce(`tracking:${tripId}`, async () => {
  const trip = await repository.getTrip(tripId)
  const [vehicle, driver, route] = await Promise.all([
    trip.vehicleId ? repository.getVehicle(trip.vehicleId) : Promise.resolve(null),
    trip.driverId ? repository.getDriver(trip.driverId) : Promise.resolve(null),
    repository.getRoute(trip.routeId),
  ])
  return { trip, vehicle, driver, route }
  })
}

export function listTrips(): Promise<Trip[]> {
  return coalesce('trips:all', () => repository.listTrips())
}

export function getDelayedTrips(): Promise<Trip[]> {
  return coalesce('trips:delayed', async () => {
    const all = await repository.listTrips()
    return all.filter(isDelayed).sort((a, b) => delayMinutes(b) - delayMinutes(a))
  })
}

export interface FleetSummary {
  total: number
  assigned: number
  available: number
  maintenance: number
  tripsInTransit: number
  tripsDelayed: number
  vehicles: Vehicle[]
}

export function getFleetSummary(): Promise<FleetSummary> {
  return coalesce('fleet:summary', async () => {
  const [fleet, all] = await Promise.all([
    repository.listVehicles(),
    repository.listTrips(),
  ])
  return {
    total: fleet.length,
    assigned: fleet.filter((v) => v.status === 'assigned').length,
    available: fleet.filter((v) => v.status === 'available').length,
    maintenance: fleet.filter((v) => v.status === 'maintenance').length,
    tripsInTransit: all.filter((t) => t.status === 'in_transit').length,
    tripsDelayed: all.filter(isDelayed).length,
    vehicles: fleet,
  }
  })
}

export function listDrivers() {
  return coalesce('drivers:all', () => repository.listDrivers())
}
