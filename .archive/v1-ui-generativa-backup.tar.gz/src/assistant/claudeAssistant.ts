/**
 * The real model, behind the same interface as the mock.
 *
 * Talks to `/api/assistant`, which is a dev-server middleware holding the API
 * key. The browser never sees it.
 *
 * Streaming rule worth noting: a component is only emitted once the NEXT one
 * has started arriving (or the stream ended). Emitting the element currently
 * being written would mean acting on a half-typed parameter — `tripId: "458"`
 * fetches the wrong trip and looks like a model error when it is ours.
 */

import type { AssistantAdapter, AssistantEvent } from './types'
import type { LayoutKind } from '../schema/types'
import { parsePartialJson } from './partialJson'

interface PartialSchema {
  title?: unknown
  layout?: unknown
  components?: unknown
}

const LAYOUTS: LayoutKind[] = ['stack', 'split', 'grid']

export const claudeAssistant: AssistantAdapter = {
  id: 'claude',
  label: 'Claude (API real)',

  async available() {
    try {
      const response = await fetch('/api/assistant/health')
      if (!response.ok) return false
      const body = (await response.json()) as { ready?: boolean }
      return body.ready === true
    } catch {
      return false
    }
  },

  async *ask(input: string): AsyncGenerator<AssistantEvent> {
    let response: Response
    try {
      response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ input }),
      })
    } catch (error) {
      yield { type: 'error', message: `Falha de rede: ${String(error)}` }
      return
    }

    if (!response.ok || !response.body) {
      yield {
        type: 'error',
        message: `Servidor respondeu ${response.status}: ${await response.text()}`,
      }
      return
    }

    const reader = response.body.getReader()
    const decoder = new TextDecoder()

    let buffer = ''
    let emittedTitle = false
    let emittedLayout = false
    let emittedNodes = 0
    let serverError: string | null = null

    const drain = function* (final: boolean): Generator<AssistantEvent> {
      const parsed = parsePartialJson(buffer) as PartialSchema | null
      if (!parsed || typeof parsed !== 'object') return

      if (!emittedTitle && typeof parsed.title === 'string' && parsed.title.length > 0) {
        // Only trust the title once something after it has arrived.
        if (final || parsed.layout !== undefined || Array.isArray(parsed.components)) {
          emittedTitle = true
          yield { type: 'title', title: parsed.title }
        }
      }

      if (!emittedLayout && typeof parsed.layout === 'string') {
        const layout = parsed.layout as LayoutKind
        if (LAYOUTS.includes(layout) && (final || Array.isArray(parsed.components))) {
          emittedLayout = true
          yield { type: 'layout', layout }
        }
      }

      if (Array.isArray(parsed.components)) {
        const settled = final ? parsed.components.length : parsed.components.length - 1
        for (let i = emittedNodes; i < settled; i++) {
          const node = parsed.components[i] as { type?: unknown; params?: unknown }
          if (!node || typeof node.type !== 'string') continue
          emittedNodes = i + 1
          yield { type: 'node', node: { type: node.type, params: node.params ?? {} } }
        }
      }
    }

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      const chunk = decoder.decode(value, { stream: true })
      for (const line of chunk.split('\n')) {
        if (!line.startsWith('data: ')) continue
        const payload = JSON.parse(line.slice(6)) as
          | { t: 'delta'; text: string }
          | { t: 'error'; message: string }
        if (payload.t === 'error') serverError = payload.message
        else buffer += payload.text
      }

      yield* drain(false)
    }

    yield* drain(true)

    if (serverError) {
      yield { type: 'error', message: serverError }
      return
    }
    if (emittedNodes === 0) {
      yield {
        type: 'error',
        message: `O modelo não produziu componentes válidos. Resposta bruta: ${buffer.slice(0, 300)}`,
      }
    }
  },
}
