/**
 * A keyword parser standing in for a language model.
 *
 * It is deliberately dumb. Its job is to prove that the pipeline works and to
 * let the POC run with no key — NOT to prove that intent parsing is easy. The
 * question "does a real model emit valid schemas reliably?" is answered only
 * by `claudeAssistant`, and the FINDINGS write-up says so.
 */

import type { AssistantAdapter, AssistantEvent } from './types'

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

function tripIds(input: string): string[] {
  return [...input.matchAll(/\b(\d{5})\b/g)].map((match) => match[1])
}

function has(input: string, ...terms: string[]): boolean {
  return terms.some((term) => input.includes(term))
}

interface Plan {
  title: string
  layout: 'stack' | 'split' | 'grid'
  nodes: { type: string; params: unknown }[]
  note?: string
}

function plan(raw: string): Plan | { error: string } {
  const input = raw
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
  const ids = tripIds(input)

  // Two trips named together — a composition nobody pre-built.
  if (ids.length >= 2 && has(input, 'compar', 'versus', ' vs', 'diferenca', 'entre')) {
    const [a, b] = ids
    return {
      title: `Comparação ${a} × ${b}`,
      layout: 'grid',
      nodes: [
        { type: 'trip_summary', params: { tripId: a } },
        { type: 'trip_summary', params: { tripId: b } },
        { type: 'trip_timeline', params: { tripId: a } },
        { type: 'trip_timeline', params: { tripId: b } },
      ],
      note: `Comparando as viagens ${a} e ${b}.`,
    }
  }

  if (ids.length >= 1 && has(input, 'planejad', 'plano', 'desvio', 'perdeu tempo', 'compar')) {
    const id = ids[0]
    return {
      title: `Desvio da viagem ${id}`,
      layout: 'split',
      nodes: [
        { type: 'route_plan', params: { tripId: id } },
        { type: 'trip_summary', params: { tripId: id } },
        { type: 'trip_timeline', params: { tripId: id } },
      ],
    }
  }

  if (ids.length >= 1 && has(input, 'onde', 'localiza', 'mapa', 'rota')) {
    const id = ids[0]
    return {
      title: `Viagem ${id}`,
      layout: 'split',
      nodes: [
        { type: 'trip_map', params: { tripId: id } },
        { type: 'trip_summary', params: { tripId: id } },
      ],
    }
  }

  if (ids.length >= 1 && has(input, 'aconteceu', 'historico', 'evento', 'timeline', 'por que')) {
    const id = ids[0]
    return {
      title: `Viagem ${id}`,
      layout: 'split',
      nodes: [
        { type: 'trip_timeline', params: { tripId: id } },
        { type: 'trip_summary', params: { tripId: id } },
      ],
    }
  }

  if (ids.length >= 1) {
    const id = ids[0]
    return {
      title: `Viagem ${id}`,
      layout: 'split',
      nodes: [
        { type: 'trip_summary', params: { tripId: id } },
        { type: 'trip_map', params: { tripId: id } },
        { type: 'trip_timeline', params: { tripId: id } },
      ],
    }
  }

  // Status-scoped listings. Ordered before the generic list so a named status
  // always wins — the bug this fixes was exactly the generic branch swallowing
  // "programadas".
  const tripStatusFilter =
    has(input, 'programad', 'agendad') ? 'scheduled'
    : has(input, 'carregament', 'carregando') ? 'loading'
    : has(input, 'cancelad') ? 'cancelled'
    : has(input, 'entregue', 'concluida', 'finalizad') ? 'delivered'
    : has(input, 'em transito', 'transito', 'rodando') ? 'in_transit'
    : null

  if (tripStatusFilter && has(input, 'viagem', 'viagens', 'lista', 'mostre', 'quais')) {
    return {
      title: 'Viagens',
      layout: 'stack',
      nodes: [
        { type: 'entity_table', params: { entity: 'trips', filter: tripStatusFilter } },
      ],
    }
  }

  const vehicleStatusFilter =
    has(input, 'disponive') ? 'available'
    : has(input, 'manutenc') ? 'maintenance'
    : has(input, 'alocad') ? 'assigned'
    : null

  if (vehicleStatusFilter && has(input, 'veiculo', 'caminh', 'frota')) {
    return {
      title: 'Veículos',
      layout: 'stack',
      nodes: [
        { type: 'entity_table', params: { entity: 'vehicles', filter: vehicleStatusFilter } },
      ],
    }
  }

  if (has(input, 'motorista', 'condutor') && has(input, 'jornada', 'excedid', 'limite')) {
    return {
      title: 'Motoristas com jornada excedida',
      layout: 'stack',
      nodes: [{ type: 'entity_table', params: { entity: 'drivers', filter: 'over_shift' } }],
    }
  }

  if (has(input, 'atras', 'atrasada', 'late')) {
    return {
      title: 'Viagens em atraso',
      layout: 'stack',
      nodes: [
        { type: 'metric_card', params: { metric: 'trips_delayed' } },
        { type: 'entity_table', params: { entity: 'trips', filter: 'delayed' } },
      ],
    }
  }

  if (has(input, 'frota', 'veiculo', 'caminh', 'panorama', 'operacao')) {
    return {
      title: 'Panorama da frota',
      layout: 'grid',
      nodes: [
        { type: 'metric_card', params: { metric: 'fleet_total' } },
        { type: 'metric_card', params: { metric: 'fleet_available' } },
        { type: 'metric_card', params: { metric: 'fleet_maintenance' } },
        { type: 'metric_card', params: { metric: 'trips_delayed' } },
        { type: 'entity_table', params: { entity: 'vehicles', filter: 'all' } },
      ],
    }
  }

  if (has(input, 'motorista', 'condutor', 'jornada')) {
    return {
      title: 'Motoristas',
      layout: 'stack',
      nodes: [{ type: 'entity_table', params: { entity: 'drivers', filter: 'all' } }],
    }
  }

  if (has(input, 'viagens', 'viagem', 'transito')) {
    return {
      title: 'Viagens',
      layout: 'stack',
      nodes: [{ type: 'entity_table', params: { entity: 'trips', filter: 'all' } }],
    }
  }

  return {
    error:
      'Não entendi. Este assistente cobre viagens, veículos e motoristas — ' +
      'tente "mostre a viagem 45872", "liste as viagens programadas" ou "como está a frota".',
  }
}

export const mockAssistant: AssistantAdapter = {
  id: 'mock',
  label: 'Mock (parser local)',
  available: async () => true,

  async *ask(input: string): AsyncGenerator<AssistantEvent> {
    // A fake think-time, so the streaming behaviour is visible without a model.
    await sleep(180)

    const result = plan(input)
    if ('error' in result) {
      yield { type: 'error', message: result.error }
      return
    }

    yield { type: 'title', title: result.title }
    yield { type: 'layout', layout: result.layout }
    if (result.note) yield { type: 'note', text: result.note }

    for (const node of result.nodes) {
      await sleep(90)
      yield { type: 'node', node }
    }
  },
}
