/**
 * Best-effort parsing of JSON that is still arriving.
 *
 * Closes whatever structures are open so a half-written object can be read.
 * Used to render components while the model is still typing.
 */

export function parsePartialJson(text: string): unknown | null {
  const trimmed = text.trim()
  if (!trimmed) return null

  // Fast path: it is already valid.
  try {
    return JSON.parse(trimmed)
  } catch {
    // fall through
  }

  const stack: string[] = []
  let inString = false
  let escaped = false
  let lastSafe = 0

  for (let i = 0; i < trimmed.length; i++) {
    const char = trimmed[i]

    if (escaped) {
      escaped = false
      continue
    }
    if (char === '\\') {
      escaped = true
      continue
    }
    if (char === '"') {
      inString = !inString
      if (!inString) lastSafe = i + 1
      continue
    }
    if (inString) continue

    if (char === '{' || char === '[') stack.push(char)
    else if (char === '}' || char === ']') {
      stack.pop()
      lastSafe = i + 1
    } else if (char === ',' || /\d|true|false|null/.test(char)) {
      lastSafe = i + 1
    }
  }

  let candidate = inString ? trimmed.slice(0, lastSafe) : trimmed
  candidate = candidate.replace(/,\s*$/, '')
  // Drop a dangling key with no value yet: {"a":1,"b"  →  {"a":1
  candidate = candidate.replace(/,?\s*"[^"]*"\s*:\s*$/, '')
  candidate = candidate.replace(/,\s*$/, '')

  const closers = stack
    .slice()
    .reverse()
    .map((open) => (open === '{' ? '}' : ']'))
    .join('')

  try {
    return JSON.parse(candidate + closers)
  } catch {
    return null
  }
}
