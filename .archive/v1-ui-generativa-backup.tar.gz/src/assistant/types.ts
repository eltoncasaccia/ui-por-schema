/**
 * The assistant contract.
 *
 * The mock and the real model implement exactly this, which is the point: the
 * app cannot tell them apart, so the architecture is validated with the mock
 * and the model's reliability is measured with the real one.
 */

import type { LayoutKind } from '../schema/types'

export type AssistantEvent =
  | { type: 'title'; title: string }
  | { type: 'layout'; layout: LayoutKind }
  | { type: 'node'; node: { type: string; params: unknown } }
  | { type: 'note'; text: string }
  | { type: 'error'; message: string }

export interface AssistantAdapter {
  id: string
  label: string
  /** Whether this adapter can run right now (the real one needs a server key). */
  available: () => Promise<boolean>
  ask: (input: string) => AsyncIterable<AssistantEvent>
}
