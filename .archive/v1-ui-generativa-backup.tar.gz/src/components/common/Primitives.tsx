/**
 * Presentational primitives. No data access, no rules, no state.
 */

import type { ReactNode } from 'react'
import type { Tone } from '../../viewmodels/format'

export function Card({
  title,
  action,
  children,
}: {
  title?: string
  action?: ReactNode
  children: ReactNode
}) {
  return (
    <section className="card">
      {title && (
        <header className="card-head">
          <h3>{title}</h3>
          {action}
        </header>
      )}
      <div className="card-body">{children}</div>
    </section>
  )
}

export function Badge({ tone, children }: { tone: Tone; children: ReactNode }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}

export function Field({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="field">
      <span className="field-label">{label}</span>
      <span className="field-value">{value}</span>
    </div>
  )
}

export function Progress({ value, tone = 'good' }: { value: number; tone?: Tone }) {
  return (
    <div className="progress" role="progressbar" aria-valuenow={value}>
      <div className={`progress-fill tone-${tone}`} style={{ width: `${value}%` }} />
    </div>
  )
}

export function Skeleton({ lines = 3, label }: { lines?: number; label?: string }) {
  return (
    <div className="skeleton" aria-busy="true">
      {label && <div className="skeleton-label">{label}</div>}
      {Array.from({ length: lines }, (_, i) => (
        <div key={i} className="skeleton-line" style={{ width: `${90 - i * 12}%` }} />
      ))}
    </div>
  )
}

export function Empty({ children }: { children: ReactNode }) {
  return <p className="empty">{children}</p>
}
