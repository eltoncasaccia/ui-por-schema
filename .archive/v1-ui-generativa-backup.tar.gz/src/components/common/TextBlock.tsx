/**
 * The one component whose content is authored by the model.
 *
 * Prose only — it must never be used to state figures, because a number here
 * is unverified in a way that every other component's numbers are not. The
 * catalogue description tells the model exactly that, and the UI marks it.
 */
export function TextBlock({ data }: { data: { text: string } }) {
  return (
    <p className="text-block">
      <span className="text-block-mark" title="Texto gerado pelo assistente">
        ✦
      </span>
      {data.text}
    </p>
  )
}
