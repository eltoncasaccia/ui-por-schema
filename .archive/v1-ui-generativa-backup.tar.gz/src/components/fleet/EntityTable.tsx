import { Card } from '../common/Primitives'
import type { Dispatch } from '../../schema/actions'
import type { TableVM } from '../../viewmodels/fleet'

export function EntityTable({
  data,
  dispatch,
}: {
  data: TableVM
  dispatch: Dispatch
}) {
  return (
    <Card title={data.caption}>
      <table className="table">
        <thead>
          <tr>
            {data.columns.map((column) => (
              <th key={column}>{column}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row) => (
            <tr
              key={row.key}
              className={row.action ? 'is-clickable' : ''}
              onClick={row.action ? () => dispatch(row.action!) : undefined}
            >
              {row.cells.map((cell, i) => (
                <td key={i}>
                  {cell.tone ? (
                    <span className={`cell-${cell.tone}`}>{cell.text}</span>
                  ) : (
                    cell.text
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  )
}
