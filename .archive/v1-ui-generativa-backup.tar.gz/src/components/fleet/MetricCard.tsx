import type { MetricVM } from '../../viewmodels/fleet'

export function MetricCard({ data }: { data: MetricVM }) {
  return (
    <div className={`metric metric-${data.tone}`}>
      <span className="metric-value">{data.value}</span>
      <span className="metric-label">{data.label}</span>
      <span className="metric-hint">{data.hint}</span>
    </div>
  )
}
