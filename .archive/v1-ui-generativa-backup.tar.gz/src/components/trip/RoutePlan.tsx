import { Card } from '../common/Primitives'
import type { RoutePlanVM } from '../../viewmodels/trip'

export function RoutePlan({ data }: { data: RoutePlanVM }) {
  return (
    <Card title={`Planejado vs. realizado · ${data.tripId}`}>
      <table className="table">
        <thead>
          <tr>
            <th>Ponto</th>
            <th>Planejado</th>
            <th>Real</th>
            <th className="num">Desvio</th>
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row) => (
            <tr key={row.name} className={row.reached ? '' : 'is-future'}>
              <td>{row.name}</td>
              <td>{row.plannedAt}</td>
              <td>{row.actualAt ?? '—'}</td>
              <td className="num">
                {row.driftMin === null ? (
                  '—'
                ) : (
                  <span className={row.driftMin > 5 ? 'drift-bad' : 'drift-ok'}>
                    {row.driftMin > 0 ? `+${row.driftMin}` : row.driftMin} min
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="map-caption">
        <span>Rota {data.routeName}</span>
        <span>
          plano {data.plannedDistance} · real {data.actualDistance}
        </span>
      </div>
    </Card>
  )
}
