import { Card } from '../common/Primitives'
import type { MapVM } from '../../viewmodels/trip'

/** A schematic, not a map. Coordinates arrive normalised 0..1 from the route. */
export function TripMap({ data }: { data: MapVM }) {
  const W = 100
  const H = 60
  const px = (x: number) => x * W
  const py = (y: number) => y * H
  const path = data.waypoints.map((w) => `${px(w.x)},${py(w.y)}`).join(' ')

  return (
    <Card title="Rota">
      <svg className="map" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={data.routeName}>
        <polyline className="map-route" points={path} />
        {data.waypoints.map((wp, i) => (
          <g key={i}>
            <circle
              className={`map-node ${wp.reached ? 'is-reached' : ''}`}
              cx={px(wp.x)}
              cy={py(wp.y)}
              r={1.8}
            />
            <text className="map-label" x={px(wp.x)} y={py(wp.y) - 3.2}>
              {wp.name}
            </text>
          </g>
        ))}
        {data.position && (
          <circle
            className="map-vehicle"
            cx={px(data.position.x)}
            cy={py(data.position.y)}
            r={2.6}
          />
        )}
      </svg>
      <div className="map-caption">
        <span>{data.routeName}</span>
        <span>{data.progress}% percorrido</span>
      </div>
    </Card>
  )
}
