import { Badge, Card, Field, Progress } from '../common/Primitives'
import type { TripSummaryVM } from '../../viewmodels/trip'

export function TripSummary({ data }: { data: TripSummaryVM }) {
  return (
    <Card title={`Viagem ${data.id}`}>
      <div className="summary-head">
        <span className="lane">{data.lane}</span>
        <Badge tone={data.statusTone}>{data.statusLabel}</Badge>
      </div>

      <div className="eta-row">
        <div>
          <span className="eta-value">{data.eta}</span>
          <span className="eta-caption">ETA atual</span>
        </div>
        <div className="eta-delta">
          <Badge tone={data.delay.tone}>{data.delay.text}</Badge>
          <span className="eta-caption">planejado {data.etaPlanned}</span>
        </div>
      </div>

      <div className="fields">
        <Field label="Veículo" value={data.vehicle} />
        <Field label="Motorista" value={data.driver} />
        <Field label="Carga" value={data.cargo} />
        <Field label="Distância" value={`${data.covered} de ${data.distance}`} />
      </div>

      <div className="progress-block">
        <div className="progress-caption">
          <span>Progresso</span>
          <span>{data.progress}%</span>
        </div>
        <Progress value={data.progress} tone={data.delayed ? 'warn' : 'good'} />
      </div>
    </Card>
  )
}
