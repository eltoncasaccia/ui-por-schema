import { Card } from '../common/Primitives'
import type { TimelineVM } from '../../viewmodels/trip'

export function TripTimeline({ data }: { data: TimelineVM }) {
  return (
    <Card title={`Linha do tempo · ${data.tripId}`}>
      <ol className="timeline">
        {data.events.map((event, i) => (
          <li key={i} className={`timeline-item is-${event.kind}`}>
            <span className="timeline-dot" aria-hidden="true" />
            <span className="timeline-time">{event.time}</span>
            <span className="timeline-label">{event.label}</span>
          </li>
        ))}
      </ol>
    </Card>
  )
}
