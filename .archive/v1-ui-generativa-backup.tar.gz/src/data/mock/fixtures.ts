/**
 * Mock fixtures. THE ONLY module allowed to hold raw arrays.
 *
 * Nothing outside `data/` may import this file — `mockRepository` is the single
 * door. `scripts/arch-check.ts` enforces it.
 */

import type { Driver, Route, Trip, Vehicle } from '../../domain/types'

/** Build an ISO timestamp for today at HH:MM, so the demo always reads "now". */
const day = new Date().toISOString().slice(0, 10)
const t = (hhmm: string) => new Date(`${day}T${hhmm}:00`).toISOString()

export const vehicles: Vehicle[] = [
  { id: 'v-1', plate: 'ABC-1234', model: 'Volvo FH 460', capacityKg: 27000, status: 'assigned', odometerKm: 412_880 },
  { id: 'v-2', plate: 'DEF-5678', model: 'Scania R450', capacityKg: 25000, status: 'assigned', odometerKm: 298_140 },
  { id: 'v-3', plate: 'GHI-9012', model: 'Mercedes Actros', capacityKg: 26000, status: 'assigned', odometerKm: 155_300 },
  { id: 'v-4', plate: 'JKL-3456', model: 'DAF XF', capacityKg: 24000, status: 'available', odometerKm: 88_420 },
  { id: 'v-5', plate: 'MNO-7890', model: 'Iveco S-Way', capacityKg: 23000, status: 'maintenance', odometerKm: 501_990 },
  { id: 'v-6', plate: 'PQR-2345', model: 'Volvo FM 380', capacityKg: 22000, status: 'assigned', odometerKm: 210_775 },
]

export const drivers: Driver[] = [
  { id: 'd-1', name: 'João Ribeiro', license: 'E', phone: '(19) 99812-4410', shiftHours: 3.5 },
  { id: 'd-2', name: 'Marcos Aurélio', license: 'E', phone: '(11) 99120-8877', shiftHours: 6.0 },
  { id: 'd-3', name: 'Patrícia Nunes', license: 'D', phone: '(15) 99745-1120', shiftHours: 1.5 },
  { id: 'd-4', name: 'Silvana Costa', license: 'E', phone: '(19) 99333-0021', shiftHours: 8.5 },
  { id: 'd-5', name: 'Rafael Tenório', license: 'E', phone: '(11) 98876-5540', shiftHours: 4.0 },
]

export const routes: Route[] = [
  {
    id: 'r-1',
    name: 'Campinas → Sorocaba',
    plannedDistanceKm: 92,
    waypoints: [
      { name: 'Campinas (CD)', x: 0.06, y: 0.78, plannedAt: t('08:00') },
      { name: 'Indaiatuba', x: 0.3, y: 0.6, plannedAt: t('08:40') },
      { name: 'Itu', x: 0.55, y: 0.46, plannedAt: t('09:30') },
      { name: 'Boituva', x: 0.76, y: 0.3, plannedAt: t('10:40') },
      { name: 'Sorocaba (Cliente)', x: 0.94, y: 0.16, plannedAt: t('11:20') },
    ],
  },
  {
    id: 'r-2',
    name: 'Jundiaí → Ribeirão Preto',
    plannedDistanceKm: 268,
    waypoints: [
      { name: 'Jundiaí (CD)', x: 0.08, y: 0.82, plannedAt: t('06:30') },
      { name: 'Limeira', x: 0.34, y: 0.62, plannedAt: t('08:10') },
      { name: 'Araraquara', x: 0.63, y: 0.4, plannedAt: t('10:05') },
      { name: 'Ribeirão Preto', x: 0.92, y: 0.2, plannedAt: t('11:45') },
    ],
  },
  {
    id: 'r-3',
    name: 'Santos → São Paulo',
    plannedDistanceKm: 78,
    waypoints: [
      { name: 'Porto de Santos', x: 0.1, y: 0.85, plannedAt: t('07:15') },
      { name: 'Cubatão', x: 0.38, y: 0.66, plannedAt: t('07:50') },
      { name: 'São Bernardo', x: 0.7, y: 0.38, plannedAt: t('09:00') },
      { name: 'São Paulo (CD)', x: 0.93, y: 0.18, plannedAt: t('09:40') },
    ],
  },
  {
    id: 'r-4',
    name: 'Campinas → Bauru',
    plannedDistanceKm: 224,
    waypoints: [
      { name: 'Campinas (CD)', x: 0.07, y: 0.8, plannedAt: t('05:00') },
      { name: 'Piracicaba', x: 0.36, y: 0.58, plannedAt: t('06:30') },
      { name: 'Jaú', x: 0.68, y: 0.34, plannedAt: t('08:40') },
      { name: 'Bauru', x: 0.93, y: 0.15, plannedAt: t('09:50') },
    ],
  },
]

export const trips: Trip[] = [
  {
    id: '45872',
    origin: 'Campinas',
    destination: 'Sorocaba',
    status: 'in_transit',
    departedAt: t('08:00'),
    etaPlanned: t('11:20'),
    etaCurrent: t('11:30'),
    vehicleId: 'v-1',
    driverId: 'd-1',
    routeId: 'r-1',
    distanceKm: 92,
    distanceCoveredKm: 63,
    cargo: 'Bebidas — 18.400 kg',
    events: [
      { at: t('08:00'), label: 'Viagem iniciada', kind: 'done' },
      { at: t('08:35'), label: 'Chegada ao carregamento', kind: 'done' },
      { at: t('09:20'), label: 'Carregamento concluído', kind: 'done' },
      { at: t('09:35'), label: 'Saída do ponto de carregamento', kind: 'done' },
      { at: t('10:48'), label: 'Em trânsito — km 63 (Boituva)', kind: 'current' },
      { at: t('11:30'), label: 'Chegada prevista ao cliente', kind: 'pending' },
    ],
  },
  {
    id: '45873',
    origin: 'Jundiaí',
    destination: 'Ribeirão Preto',
    status: 'in_transit',
    departedAt: t('06:30'),
    etaPlanned: t('11:45'),
    etaCurrent: t('13:10'),
    vehicleId: 'v-2',
    driverId: 'd-2',
    routeId: 'r-2',
    distanceKm: 268,
    distanceCoveredKm: 150,
    cargo: 'Insumos agrícolas — 24.100 kg',
    events: [
      { at: t('06:30'), label: 'Viagem iniciada', kind: 'done' },
      { at: t('08:25'), label: 'Passagem por Limeira (+15 min)', kind: 'done' },
      { at: t('09:40'), label: 'Parada não prevista — congestionamento SP-330', kind: 'done' },
      { at: t('10:55'), label: 'Em trânsito — km 150', kind: 'current' },
      { at: t('13:10'), label: 'Chegada prevista ao cliente', kind: 'pending' },
    ],
  },
  {
    id: '45874',
    origin: 'Santos',
    destination: 'São Paulo',
    status: 'delivered',
    departedAt: t('07:15'),
    etaPlanned: t('09:40'),
    etaCurrent: t('09:32'),
    vehicleId: 'v-3',
    driverId: 'd-3',
    routeId: 'r-3',
    distanceKm: 78,
    distanceCoveredKm: 78,
    cargo: 'Contêiner importação — 21.000 kg',
    events: [
      { at: t('07:15'), label: 'Viagem iniciada', kind: 'done' },
      { at: t('07:52'), label: 'Saída de Cubatão', kind: 'done' },
      { at: t('09:05'), label: 'Chegada em São Bernardo', kind: 'done' },
      { at: t('09:32'), label: 'Entrega concluída', kind: 'done' },
    ],
  },
  {
    id: '45875',
    origin: 'Campinas',
    destination: 'Bauru',
    status: 'in_transit',
    departedAt: t('05:00'),
    etaPlanned: t('09:50'),
    etaCurrent: t('10:35'),
    vehicleId: 'v-6',
    driverId: 'd-5',
    routeId: 'r-4',
    distanceKm: 224,
    distanceCoveredKm: 198,
    cargo: 'Autopeças — 12.700 kg',
    events: [
      { at: t('05:00'), label: 'Viagem iniciada', kind: 'done' },
      { at: t('06:45'), label: 'Passagem por Piracicaba', kind: 'done' },
      { at: t('08:20'), label: 'Pane elétrica — 40 min parado', kind: 'done' },
      { at: t('09:15'), label: 'Em trânsito — km 198', kind: 'current' },
      { at: t('10:35'), label: 'Chegada prevista ao cliente', kind: 'pending' },
    ],
  },
  {
    id: '45876',
    origin: 'Sorocaba',
    destination: 'Campinas',
    status: 'scheduled',
    departedAt: null,
    etaPlanned: t('16:00'),
    etaCurrent: t('16:00'),
    vehicleId: 'v-4',
    driverId: 'd-4',
    routeId: 'r-1',
    distanceKm: 92,
    distanceCoveredKm: 0,
    cargo: 'Retorno vazio',
    events: [{ at: t('14:00'), label: 'Carregamento programado', kind: 'pending' }],
  },
  {
    id: '45877',
    origin: 'Campinas',
    destination: 'Sorocaba',
    status: 'cancelled',
    departedAt: null,
    etaPlanned: t('12:00'),
    etaCurrent: t('12:00'),
    vehicleId: null,
    driverId: null,
    routeId: 'r-1',
    distanceKm: 92,
    distanceCoveredKm: 0,
    cargo: 'Cancelada pelo cliente',
    events: [{ at: t('07:00'), label: 'Viagem cancelada pelo cliente', kind: 'done' }],
  },
]
