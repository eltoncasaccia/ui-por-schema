/**
 * The single door to persisted data.
 *
 * Everything above this line pretends there is a real backend: calls are async,
 * they take 200-500ms, and they can fail. Swapping these bodies for `fetch()`
 * is the only change needed to put a real API behind the app.
 */

import type { Driver, Route, Trip, Vehicle } from '../domain/types'
import { drivers, routes, trips, vehicles } from './mock/fixtures'

/** Simulated network latency, so loading states are real and not theoretical. */
const MIN_MS = 200
const MAX_MS = 500

function latency(): Promise<void> {
  const ms = MIN_MS + Math.random() * (MAX_MS - MIN_MS)
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * An error written for a language model to recover from, not for a stack trace.
 * A bare "404" tells the model nothing; a list of near-misses lets it retry.
 */
export class NotFoundError extends Error {
  constructor(what: string, id: string, available: string[]) {
    super(
      `${what} "${id}" não existe. ${what}s disponíveis: ${available.join(', ')}.`,
    )
    this.name = 'NotFoundError'
  }
}

function clone<T>(value: T): T {
  return structuredClone(value)
}

export const repository = {
  async listTrips(): Promise<Trip[]> {
    await latency()
    return clone(trips)
  },

  async getTrip(id: string): Promise<Trip> {
    await latency()
    const found = trips.find((t) => t.id === id)
    if (!found) throw new NotFoundError('Viagem', id, trips.map((t) => t.id))
    return clone(found)
  },

  async listVehicles(): Promise<Vehicle[]> {
    await latency()
    return clone(vehicles)
  },

  async getVehicle(id: string): Promise<Vehicle | null> {
    await latency()
    const found = vehicles.find((v) => v.id === id || v.plate === id)
    return found ? clone(found) : null
  },

  async listDrivers(): Promise<Driver[]> {
    await latency()
    return clone(drivers)
  },

  async getDriver(id: string): Promise<Driver | null> {
    await latency()
    const found = drivers.find((d) => d.id === id)
    return found ? clone(found) : null
  },

  async getRoute(id: string): Promise<Route> {
    await latency()
    const found = routes.find((r) => r.id === id)
    if (!found) throw new NotFoundError('Rota', id, routes.map((r) => r.id))
    return clone(found)
  },

  /** Persists a status change. In a real system this is a POST. */
  async saveTripStatus(id: string, status: Trip['status']): Promise<Trip> {
    await latency()
    const found = trips.find((t) => t.id === id)
    if (!found) throw new NotFoundError('Viagem', id, trips.map((t) => t.id))
    found.status = status
    return clone(found)
  },
}
