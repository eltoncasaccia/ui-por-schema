/**
 * Business rules. Pure functions over domain types.
 *
 * These exist here — not in components, not in view models — so that the
 * answer to "is this trip late?" is the same everywhere in the system.
 * `scripts/arch-check.ts` enforces that components never import this module.
 */

import type { Driver, Trip, TripTracking, Vehicle } from './types'

/** Maximum shift length before a driver must legally stop. */
const MAX_SHIFT_HOURS = 8

/** Slack we allow before calling a trip late. */
const DELAY_TOLERANCE_MIN = 10

export interface RuleResult {
  ok: boolean
  reason?: string
}

/** Minutes the current ETA slips past the planned ETA. Negative means ahead. */
export function delayMinutes(trip: Trip): number {
  const planned = new Date(trip.etaPlanned).getTime()
  const current = new Date(trip.etaCurrent).getTime()
  return Math.round((current - planned) / 60_000)
}

export function isDelayed(trip: Trip): boolean {
  if (trip.status === 'cancelled' || trip.status === 'delivered') return false
  return delayMinutes(trip) > DELAY_TOLERANCE_MIN
}

/** 0..100. Derived from distance, never stored — one source of truth. */
export function progressPct(trip: Trip): number {
  if (trip.distanceKm <= 0) return 0
  const pct = (trip.distanceCoveredKm / trip.distanceKm) * 100
  return Math.max(0, Math.min(100, Math.round(pct)))
}

/** A trip cannot start without a vehicle, a driver, and a legal shift. */
export function canStart(
  trip: Trip,
  vehicle: Vehicle | null,
  driver: Driver | null,
): RuleResult {
  if (trip.status === 'cancelled')
    return { ok: false, reason: 'Viagem cancelada não pode ser iniciada.' }
  if (trip.status !== 'scheduled')
    return { ok: false, reason: 'Viagem já iniciada.' }
  if (!vehicle) return { ok: false, reason: 'Viagem sem veículo atribuído.' }
  if (vehicle.status === 'maintenance')
    return { ok: false, reason: `Veículo ${vehicle.plate} está em manutenção.` }
  if (!driver) return { ok: false, reason: 'Viagem sem motorista atribuído.' }
  if (driver.shiftHours >= MAX_SHIFT_HOURS)
    return {
      ok: false,
      reason: `Motorista ${driver.name} excedeu a jornada de ${MAX_SHIFT_HOURS}h.`,
    }
  return { ok: true }
}

/** Which status transitions the domain permits. */
const ALLOWED_TRANSITIONS: Record<Trip['status'], Trip['status'][]> = {
  scheduled: ['loading', 'cancelled'],
  loading: ['in_transit', 'cancelled'],
  in_transit: ['delivered', 'cancelled'],
  delivered: [],
  cancelled: [],
}

export function canTransition(from: Trip['status'], to: Trip['status']): RuleResult {
  if (ALLOWED_TRANSITIONS[from].includes(to)) return { ok: true }
  return { ok: false, reason: `Transição ${from} → ${to} não é permitida.` }
}

/** How far the trip has drifted from its planned route timing, per waypoint. */
export function routeDeviation(tracking: TripTracking) {
  const { trip, route } = tracking
  const reached = trip.events.filter((e) => e.kind === 'done').length
  return route.waypoints.map((wp, i) => {
    const event = trip.events[i]
    const plannedMs = new Date(wp.plannedAt).getTime()
    const actualMs = event ? new Date(event.at).getTime() : null
    return {
      name: wp.name,
      plannedAt: wp.plannedAt,
      actualAt: event?.at ?? null,
      reached: i < reached,
      driftMin:
        actualMs === null ? null : Math.round((actualMs - plannedMs) / 60_000),
    }
  })
}
