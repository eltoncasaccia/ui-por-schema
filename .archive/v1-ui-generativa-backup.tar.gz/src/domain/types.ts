/**
 * Domain types. Pure data shapes — no React, no I/O, no formatting.
 * Everything the business talks about lives here and nowhere else.
 */

export type TripStatus =
  | 'scheduled'
  | 'loading'
  | 'in_transit'
  | 'delivered'
  | 'cancelled'

export type TripEventKind = 'done' | 'current' | 'pending'

export interface TripEvent {
  /** ISO timestamp */
  at: string
  label: string
  kind: TripEventKind
}

export interface Trip {
  id: string
  origin: string
  destination: string
  status: TripStatus
  /** ISO timestamp, null while scheduled */
  departedAt: string | null
  /** What was promised when the trip was planned */
  etaPlanned: string
  /** What we currently believe, given telemetry */
  etaCurrent: string
  vehicleId: string | null
  driverId: string | null
  routeId: string
  distanceKm: number
  distanceCoveredKm: number
  cargo: string
  events: TripEvent[]
}

export type VehicleStatus = 'available' | 'assigned' | 'maintenance'

export interface Vehicle {
  id: string
  plate: string
  model: string
  capacityKg: number
  status: VehicleStatus
  odometerKm: number
}

export interface Driver {
  id: string
  name: string
  license: string
  phone: string
  /** Hours driven in the current shift — feeds a real business rule */
  shiftHours: number
}

export interface RouteWaypoint {
  name: string
  /** Normalised 0..1 coordinates. The POC draws a schematic, not a real map. */
  x: number
  y: number
  /** Planned arrival, ISO timestamp */
  plannedAt: string
}

export interface Route {
  id: string
  name: string
  plannedDistanceKm: number
  waypoints: RouteWaypoint[]
}

/** A trip with its relations already joined — the shape queries return. */
export interface TripTracking {
  trip: Trip
  vehicle: Vehicle | null
  driver: Driver | null
  route: Route
}
