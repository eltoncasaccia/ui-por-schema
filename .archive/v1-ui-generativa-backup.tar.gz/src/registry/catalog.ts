/**
 * The catalogue handed to the model, derived from the registry.
 *
 * Nothing here is written by hand. Adding a component to the registry adds it
 * to the model's vocabulary in the same commit — there is no second list to
 * forget to update, which is the usual way these systems rot.
 */

import { z } from 'zod'
import { componentRegistry } from './registry'

export interface CatalogEntry {
  id: string
  label: string
  description: string
  examples: string[]
  params: unknown
}

export function buildCatalog(): CatalogEntry[] {
  return Object.values(componentRegistry).map((definition) => ({
    id: definition.id,
    label: definition.label,
    description: definition.description,
    examples: definition.examples,
    params: z.toJSONSchema(definition.params, { io: 'input' }),
  }))
}

/** The catalogue rendered as prompt text. */
export function catalogPrompt(): string {
  return buildCatalog()
    .map((entry) => {
      const params = JSON.stringify(entry.params)
      const examples = entry.examples.map((e) => `"${e}"`).join(', ')
      return [
        `### ${entry.id}`,
        entry.description,
        `params: ${params}`,
        `exemplos: ${examples}`,
      ].join('\n')
    })
    .join('\n\n')
}
