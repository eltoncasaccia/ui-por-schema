/**
 * The single source of truth for a renderable component.
 *
 * Registering one here produces, from one declaration:
 *   - the runtime validator for the schema node        (`params`)
 *   - the tool description the model is given          (`description`)
 *   - how its data is loaded, outside React            (`load`)
 *   - how its data is derived, purely, during render   (`select`)
 *   - the React component itself                       (`render`)
 *
 * Keeping these together is what stops the model's catalogue and the app's
 * actual capabilities from drifting apart.
 */

import type { ComponentType } from 'react'
import type { z } from 'zod'
import type { Dispatch } from '../schema/actions'
import type { DataState } from '../state/dataStore'

export interface ComponentDefinition<P, VM> {
  /** The name the model uses. Anything not registered is rejected. */
  id: string
  /** Human label for the UI. */
  label: string
  /**
   * Written for the model, not for a developer. This string materially changes
   * behaviour — it is closer to code than to documentation.
   */
  description: string
  /** Example phrasings that should select this component. Sent in the prompt. */
  examples: string[]
  /**
   * How much room the component needs. Declared by the component, NOT chosen by
   * the model — the layout engine reads this so that asking for a "grid" can
   * never squeeze a table into a 200px tile.
   */
  size: 'tile' | 'block'
  params: z.ZodType<P>
  /**
   * Fetches whatever this node needs into the persistent store. Runs in the
   * pipeline, never during render — that is what keeps React out of data
   * fetching and removes the need for effects.
   */
  load: (params: P) => Promise<void>
  /**
   * Pure projection from persistent state to what the component draws.
   * Runs during render. Must not fetch, must not mutate.
   * Returns null when the data is not in the store yet.
   */
  select: (state: DataState, params: P) => VM | null
  /** Receives resolved data and a dispatcher. Never fetches, never decides. */
  render: ComponentType<{ data: VM; dispatch: Dispatch }>
}

/** Type-erased view, for the registry map. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type AnyComponentDefinition = ComponentDefinition<any, any>

export function defineComponent<P, VM>(
  definition: ComponentDefinition<P, VM>,
): ComponentDefinition<P, VM> {
  return definition
}
