import { z } from 'zod'
import { EntityTable } from '../../components/fleet/EntityTable'
import { MetricCard } from '../../components/fleet/MetricCard'
import { TextBlock } from '../../components/common/TextBlock'
import {
  getDelayedTrips,
  getFleetSummary,
  listDrivers,
  listTrips,
} from '../../application/queries'
import { dataActions } from '../../state/dataStore'
import {
  FILTERS_BY_ENTITY,
  METRICS,
  TABLE_ENTITIES,
  TABLE_FILTERS,
  TRIP_FILTERS,
  VEHICLE_FILTERS,
  metricVM,
  tableVM,
} from '../../viewmodels/fleet'
import { defineComponent } from '../defineComponent'

export const metricCard = defineComponent({
  id: 'metric_card',
  label: 'Indicador',
  description:
    'Um número único da operação. O parâmetro escolhe QUAL indicador; o valor vem ' +
    'do sistema. Use vários lado a lado com layout "grid" para montar um panorama.',
  examples: ['como está a frota', 'panorama da operação', 'quantas viagens atrasadas'],
  size: 'tile',
  params: z.object({
    metric: z
      .enum(METRICS)
      .describe('Qual indicador exibir. Só estes valores são aceitos.'),
  }),
  load: async () => {
    const summary = await getFleetSummary()
    dataActions.ingestVehicles(summary.vehicles)
    dataActions.ingestFleetCounts({
      total: summary.total,
      assigned: summary.assigned,
      available: summary.available,
      maintenance: summary.maintenance,
      tripsInTransit: summary.tripsInTransit,
      tripsDelayed: summary.tripsDelayed,
    })
  },
  select: (state, params) => metricVM(state, params.metric),
  render: MetricCard,
})

export const entityTable = defineComponent({
  id: 'entity_table',
  label: 'Tabela',
  description:
    'Lista tabular de viagens, veículos ou motoristas, com filtro. Use sempre que ' +
    'o usuário pedir uma listagem. Se ele citar um status ("programadas", ' +
    '"em trânsito", "canceladas", "em manutenção", "disponíveis"), passe o filtro ' +
    'correspondente — NÃO devolva a lista completa. Linhas de viagem abrem a viagem.',
  examples: [
    'mostre as viagens em atraso',
    'liste as viagens programadas',
    'quais viagens estão em trânsito',
    'viagens canceladas',
    'quais veículos estão disponíveis',
    'veículos em manutenção',
    'motoristas com jornada excedida',
  ],
  size: 'block',
  params: z
    .object({
      entity: z.enum(TABLE_ENTITIES).describe('Qual coleção listar.'),
      filter: z
        .enum(TABLE_FILTERS)
        .default('all')
        .describe(
          `Filtro. Para trips: ${TRIP_FILTERS.join(', ')}. ` +
            `Para vehicles: ${VEHICLE_FILTERS.join(', ')}. ` +
            'Para drivers: all, over_shift. Use "all" só quando o usuário não pedir recorte.',
        ),
    })
    // Cross-field validation: "motoristas em manutenção" is nonsense, and the
    // gate should say so instead of quietly listing everything.
    .superRefine((value, ctx) => {
      const allowed = FILTERS_BY_ENTITY[value.entity]
      if (allowed.includes(value.filter)) return
      ctx.addIssue({
        code: 'custom',
        path: ['filter'],
        message:
          `filtro "${value.filter}" não se aplica a ${value.entity} ` +
          `(aceitos: ${allowed.join(', ')})`,
      })
    }),
  load: async ({ entity, filter }) => {
    if (entity === 'trips') {
      if (filter === 'delayed') {
        dataActions.ingestTrips(await getDelayedTrips(), 'delayedTripIds')
      } else {
        dataActions.ingestTrips(await listTrips(), 'allTripIds')
      }
      return
    }
    if (entity === 'vehicles') {
      const summary = await getFleetSummary()
      dataActions.ingestVehicles(summary.vehicles)
      return
    }
    dataActions.ingestDrivers(await listDrivers())
  },
  select: (state, params) => tableVM(state, params.entity, params.filter),
  render: EntityTable,
})

export const textBlock = defineComponent({
  id: 'text_block',
  label: 'Texto',
  description:
    'Uma frase curta de contexto ou conclusão. NÃO use para afirmar números, ' +
    'horários, placas ou nomes — esses vêm dos outros componentes, que leem o ' +
    'sistema. Use no máximo um por resposta, como abertura.',
  examples: ['explique o atraso', 'resuma a situação'],
  size: 'block',
  params: z.object({
    text: z.string().max(240).describe('Frase curta, no máximo 240 caracteres.'),
  }),
  load: async () => {},
  select: (_state, params) => params,
  render: TextBlock,
})
