import { z } from 'zod'
import { TripMap } from '../../components/trip/TripMap'
import { TripSummary } from '../../components/trip/TripSummary'
import { TripTimeline } from '../../components/trip/TripTimeline'
import { RoutePlan } from '../../components/trip/RoutePlan'
import { getTripTracking } from '../../application/queries'
import { dataActions } from '../../state/dataStore'
import {
  routePlanVM,
  selectTracking,
  tripMapVM,
  tripSummaryVM,
  tripTimelineVM,
} from '../../viewmodels/trip'
import { defineComponent } from '../defineComponent'

const tripParams = z.object({
  tripId: z
    .string()
    .describe('Número da viagem, exatamente como o usuário informou. Ex: "45872".'),
})

/** All four trip components share one join-shaped query. */
async function loadTracking({ tripId }: { tripId: string }) {
  dataActions.ingestTracking(await getTripTracking(tripId))
}

export const tripSummary = defineComponent({
  id: 'trip_summary',
  label: 'Resumo da viagem',
  description:
    'Cartão com o estado atual de UMA viagem: trecho, status, ETA atual vs. planejado, ' +
    'atraso, veículo, motorista, carga e progresso percorrido. É o componente padrão ' +
    'quando o usuário pergunta sobre uma viagem específica.',
  examples: ['mostre a viagem 45872', 'como está a viagem 45873', 'status da 45875'],
  size: 'block',
  params: tripParams,
  load: loadTracking,
  select: (state, params) => {
    const tracking = selectTracking(state, params.tripId)
    return tracking ? tripSummaryVM(tracking) : null
  },
  render: TripSummary,
})

export const tripTimeline = defineComponent({
  id: 'trip_timeline',
  label: 'Linha do tempo',
  description:
    'Sequência cronológica de eventos de UMA viagem (saída, carregamento, paradas, ' +
    'ocorrências, chegada prevista). Use quando o usuário quiser entender o que ' +
    'aconteceu, investigar um atraso ou ver o histórico.',
  examples: [
    'o que aconteceu na viagem 45873',
    'histórico da viagem 45872',
    'por que a 45875 atrasou',
  ],
  size: 'block',
  params: tripParams,
  load: loadTracking,
  select: (state, params) => {
    const tracking = selectTracking(state, params.tripId)
    return tracking ? tripTimelineVM(tracking) : null
  },
  render: TripTimeline,
})

export const tripMap = defineComponent({
  id: 'trip_map',
  label: 'Mapa da rota',
  description:
    'Esquema visual da rota de UMA viagem, com os pontos de passagem e a posição ' +
    'atual do veículo. Use para complementar o resumo quando a pergunta envolver ' +
    'localização, trajeto ou "onde está".',
  examples: ['onde está a viagem 45872', 'mostre a rota da 45873'],
  size: 'block',
  params: tripParams,
  load: loadTracking,
  select: (state, params) => {
    const tracking = selectTracking(state, params.tripId)
    return tracking ? tripMapVM(tracking) : null
  },
  render: TripMap,
})

export const routePlan = defineComponent({
  id: 'route_plan',
  label: 'Planejado vs. realizado',
  description:
    'Tabela ponto a ponto comparando o horário planejado da rota com o horário real, ' +
    'mostrando o desvio em minutos em cada trecho. Use quando o usuário pedir ' +
    'comparação com o plano, análise de desvio ou onde a viagem perdeu tempo.',
  examples: [
    'compare a viagem 45873 com a rota planejada',
    'onde a 45875 perdeu tempo',
    'desvio da viagem 45872',
  ],
  size: 'block',
  params: tripParams,
  load: loadTracking,
  select: (state, params) => {
    const tracking = selectTracking(state, params.tripId)
    return tracking ? routePlanVM(tracking) : null
  },
  render: RoutePlan,
})
