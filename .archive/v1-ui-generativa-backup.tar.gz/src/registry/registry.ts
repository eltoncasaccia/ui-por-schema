/**
 * The Component Registry — the allow-list.
 *
 * The assistant can compose anything in this map and nothing outside it. There
 * is no path from a model's output to an arbitrary React component, because
 * the only thing the model ever emits is a string key that is looked up here.
 */

import type { AnyComponentDefinition } from './defineComponent'
import { entityTable, metricCard, textBlock } from './definitions/fleet'
import { routePlan, tripMap, tripSummary, tripTimeline } from './definitions/trip'

const definitions: AnyComponentDefinition[] = [
  tripSummary,
  tripTimeline,
  tripMap,
  routePlan,
  metricCard,
  entityTable,
  textBlock,
]

export const componentRegistry: Record<string, AnyComponentDefinition> =
  Object.fromEntries(definitions.map((definition) => [definition.id, definition]))

export const componentIds = definitions.map((definition) => definition.id)

export function getComponent(id: string): AnyComponentDefinition | undefined {
  return componentRegistry[id]
}
