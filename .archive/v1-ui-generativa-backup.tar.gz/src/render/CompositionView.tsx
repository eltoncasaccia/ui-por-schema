/**
 * The renderer: schema in, React out.
 *
 * Note what is absent — no fetching, no `useEffect`, no awaiting. By the time
 * a node reaches this file its data is either in the store or still on its way,
 * and either case is a pure function of state. React's only job here is to draw.
 */

import { getComponent } from '../registry/registry'
import type { Composition, NodeState } from '../schema/types'
import type { Dispatch } from '../schema/actions'
import { dataStore, type DataState } from '../state/dataStore'
import { useStore } from '../state/useStore'
import { Skeleton } from '../components/common/Primitives'
import { NodeErrorBoundary } from './ErrorBoundary'
import { Layout, type LayoutItem } from './Layout'

export function CompositionView({
  composition,
  dispatch,
}: {
  composition: Composition
  dispatch: Dispatch
}) {
  const data = useStore(dataStore)

  const items: LayoutItem[] = composition.nodes.map((node, index) => {
    const definition = getComponent(node.type)
    return {
      key: `${index}-${node.type}`,
      size: definition?.size ?? 'block',
      node: (
        <NodeErrorBoundary name={node.type}>
          <NodeSlot node={node} state={data} dispatch={dispatch} />
        </NodeErrorBoundary>
      ),
    }
  })

  return <Layout kind={composition.layout} items={items} />
}

function NodeSlot({
  node,
  state,
  dispatch,
}: {
  node: NodeState
  state: DataState
  dispatch: Dispatch
}) {
  const definition = getComponent(node.type)

  // Unreachable through the validated path; kept because the registry is the
  // security boundary and should fail loudly if something slips past it.
  if (!definition) {
    return <div className="node-error">Componente “{node.type}” não registrado.</div>
  }

  if (node.status === 'error') {
    return (
      <div className="node-error">
        <strong>{definition.label}</strong> não pôde ser carregado
        <code>{node.error}</code>
      </div>
    )
  }

  const viewModel = definition.select(state, node.params)

  if (node.status === 'pending' || viewModel === null) {
    return <Skeleton label={definition.label} lines={definition.size === 'tile' ? 1 : 3} />
  }

  const Render = definition.render
  return <Render data={viewModel} dispatch={dispatch} />
}
