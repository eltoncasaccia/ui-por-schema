import { Component, type ErrorInfo, type ReactNode } from 'react'

/**
 * One boundary per rendered node, so a single bad component degrades to a
 * message instead of blanking the composition. Class component because React
 * offers no hook equivalent.
 */
export class NodeErrorBoundary extends Component<
  { name: string; children: ReactNode },
  { message: string | null }
> {
  state = { message: null as string | null }

  static getDerivedStateFromError(error: Error) {
    return { message: error.message }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error(`[render] ${this.props.name} falhou`, error, info)
  }

  render() {
    if (this.state.message !== null) {
      return (
        <div className="node-error">
          <strong>{this.props.name}</strong> falhou ao renderizar
          <code>{this.state.message}</code>
        </div>
      )
    }
    return this.props.children
  }
}
