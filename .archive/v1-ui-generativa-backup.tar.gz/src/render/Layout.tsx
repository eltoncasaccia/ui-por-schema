/**
 * Layout. Deliberately small — this is the honest size of the thing the
 * original spec called a "Layout Engine".
 *
 * The schema may pick one of three arrangements by name. It cannot express
 * widths, gaps, colours or CSS of any kind, and it does not decide how much
 * room a component gets: that comes from the component's own `size`.
 */

import type { ReactNode } from 'react'
import type { LayoutKind } from '../schema/types'

export interface LayoutItem {
  key: string
  size: 'tile' | 'block'
  node: ReactNode
}

export function Layout({ kind, items }: { kind: LayoutKind; items: LayoutItem[] }) {
  const groups = groupConsecutiveTiles(items)

  return (
    <div className={`layout layout-${kind}`}>
      {groups.map((group, index) =>
        group.kind === 'tiles' ? (
          <div className="tile-row" key={index}>
            {group.items.map((item) => (
              <div className="tile" key={item.key}>
                {item.node}
              </div>
            ))}
          </div>
        ) : (
          group.items.map((item, i) => (
            <div className={blockClass(kind, i)} key={item.key}>
              {item.node}
            </div>
          ))
        ),
      )}
    </div>
  )
}

/**
 * `split` puts the first two blocks side by side and drops the rest full
 * width — the shape a tracking screen wants. `grid` flows every block in two
 * columns. `stack` is one column. That is the entire vocabulary.
 */
function blockClass(kind: LayoutKind, index: number): string {
  if (kind === 'split') return index < 2 ? 'block block-half' : 'block block-full'
  if (kind === 'grid') return 'block block-half'
  return 'block block-full'
}

type Group = { kind: 'tiles' | 'blocks'; items: LayoutItem[] }

function groupConsecutiveTiles(items: LayoutItem[]): Group[] {
  const groups: Group[] = []
  for (const item of items) {
    const kind = item.size === 'tile' ? 'tiles' : 'blocks'
    const last = groups[groups.length - 1]
    if (last && last.kind === kind) last.items.push(item)
    else groups.push({ kind, items: [item] })
  }
  return groups
}
