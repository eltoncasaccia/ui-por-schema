/**
 * The only way a rendered component can talk back to the application.
 *
 * Components emit a declarative action; they do not call queries, mutate state,
 * or know what happens next. This keeps "click a row" from turning into
 * orchestration living inside a table.
 */

export type UiAction =
  | { type: 'open_trip'; tripId: string }
  | { type: 'ask'; text: string }

export type Dispatch = (action: UiAction) => void
