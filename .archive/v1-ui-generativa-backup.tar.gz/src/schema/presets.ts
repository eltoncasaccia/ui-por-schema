/**
 * Schemas written by a developer.
 *
 * The point of this file is that it is unremarkable: clicking a menu item and
 * asking the assistant produce the same kind of object and travel the same
 * pipeline. The model is not a special case — it is just another author.
 */

import type { ViewSchema } from './types'

export function tripTrackingSchema(tripId: string): ViewSchema {
  return {
    title: `Viagem ${tripId}`,
    layout: 'split',
    components: [
      { type: 'trip_summary', params: { tripId } },
      { type: 'trip_map', params: { tripId } },
      { type: 'trip_timeline', params: { tripId } },
    ],
  }
}

export const delayedTripsSchema: ViewSchema = {
  title: 'Viagens em atraso',
  layout: 'stack',
  components: [
    { type: 'metric_card', params: { metric: 'trips_delayed' } },
    { type: 'entity_table', params: { entity: 'trips', filter: 'delayed' } },
  ],
}

export const fleetOverviewSchema: ViewSchema = {
  title: 'Panorama da frota',
  layout: 'grid',
  components: [
    { type: 'metric_card', params: { metric: 'fleet_total' } },
    { type: 'metric_card', params: { metric: 'fleet_available' } },
    { type: 'metric_card', params: { metric: 'fleet_maintenance' } },
    { type: 'metric_card', params: { metric: 'trips_in_transit' } },
    { type: 'metric_card', params: { metric: 'trips_delayed' } },
    { type: 'entity_table', params: { entity: 'vehicles', filter: 'all' } },
  ],
}

export const allTripsSchema: ViewSchema = {
  title: 'Todas as viagens',
  layout: 'stack',
  components: [{ type: 'entity_table', params: { entity: 'trips', filter: 'all' } }],
}

export const driversSchema: ViewSchema = {
  title: 'Motoristas',
  layout: 'stack',
  components: [{ type: 'entity_table', params: { entity: 'drivers', filter: 'all' } }],
}
