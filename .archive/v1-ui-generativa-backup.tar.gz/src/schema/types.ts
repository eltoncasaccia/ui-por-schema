/**
 * The contract between the assistant and the UI.
 *
 * This is the whole surface a language model is allowed to produce. It names
 * components and passes parameters — it never carries markup, styles, data, or
 * code. The front end decides how any of it looks.
 */

export type LayoutKind = 'stack' | 'split' | 'grid'

export interface ViewNode {
  /** Must match a key in the ComponentRegistry. Anything else is rejected. */
  type: string
  /** Validated against the component's own Zod schema before rendering. */
  params: Record<string, unknown>
}

export interface ViewSchema {
  title: string
  layout: LayoutKind
  components: ViewNode[]
}

/** Per-node runtime state, owned by the pipeline and read by the renderer. */
export type NodeStatus = 'pending' | 'ready' | 'error'

export interface NodeState {
  type: string
  params: Record<string, unknown>
  status: NodeStatus
  error?: string
}

export type CompositionSource = 'navigation' | 'assistant'

export interface Composition {
  id: string
  title: string
  layout: LayoutKind
  nodes: NodeState[]
  source: CompositionSource
  /** Kept verbatim so the Debug panel can show exactly what was produced. */
  schema: ViewSchema
  createdAt: number
}

/**
 * Stable identity of a view, independent of when it was rendered.
 *
 * Pinning used to key on the composition id, which is created fresh every time
 * a view opens — so reopening a pinned trip produced a new id, the star read as
 * unpinned, and pinning again appended a duplicate. A view is the same view
 * when its schema is the same, so that is what identifies it.
 */
export function viewKey(schema: ViewSchema): string {
  return JSON.stringify({
    layout: schema.layout,
    components: schema.components.map((node) => ({
      type: node.type,
      params: Object.fromEntries(
        Object.entries(node.params).sort(([a], [b]) => a.localeCompare(b)),
      ),
    })),
  })
}
