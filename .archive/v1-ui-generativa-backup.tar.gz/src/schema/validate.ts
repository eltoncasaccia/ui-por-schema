/**
 * The gate. Nothing renders without passing through here.
 *
 * Two independent checks: the shape of the schema itself, and each node's
 * params against the schema its own component declares. A node naming a
 * component that does not exist is rejected outright — this is what makes
 * "the model cannot render arbitrary things" a property, not a promise.
 */

import { z } from 'zod'
import { getComponent } from '../registry/registry'
import type { ViewSchema } from './types'

const rawSchema = z.object({
  title: z.string().min(1).max(120),
  layout: z.enum(['stack', 'split', 'grid']),
  components: z
    .array(z.object({ type: z.string(), params: z.record(z.string(), z.unknown()).default({}) }))
    .min(1)
    .max(8),
})

export interface ValidationSuccess {
  ok: true
  schema: ViewSchema
  /** Nodes dropped because they did not validate, kept for the trace. */
  rejected: { type: string; reason: string }[]
}

export interface ValidationFailure {
  ok: false
  errors: string[]
}

export type ValidationResult = ValidationSuccess | ValidationFailure

export function validateViewSchema(input: unknown): ValidationResult {
  const parsed = rawSchema.safeParse(input)
  if (!parsed.success) {
    return {
      ok: false,
      errors: parsed.error.issues.map(
        (issue) => `${issue.path.join('.') || '(raiz)'}: ${issue.message}`,
      ),
    }
  }

  const components: ViewSchema['components'] = []
  const rejected: { type: string; reason: string }[] = []

  for (const node of parsed.data.components) {
    const definition = getComponent(node.type)
    if (!definition) {
      rejected.push({ type: node.type, reason: 'componente não registrado' })
      continue
    }
    const params = definition.params.safeParse(node.params)
    if (!params.success) {
      rejected.push({
        type: node.type,
        reason: params.error.issues
          .map((i) => `${i.path.join('.') || 'params'}: ${i.message}`)
          .join('; '),
      })
      continue
    }
    // Store the PARSED params: defaults are applied and types coerced once,
    // so nothing downstream re-validates or guesses.
    components.push({ type: node.type, params: params.data as Record<string, unknown> })
  }

  if (components.length === 0) {
    return {
      ok: false,
      errors: rejected.length
        ? rejected.map((r) => `${r.type}: ${r.reason}`)
        : ['schema sem componentes válidos'],
    }
  }

  return {
    ok: true,
    schema: { title: parsed.data.title, layout: parsed.data.layout, components },
    rejected,
  }
}

/** Validates a single node, used by the streaming path as nodes arrive. */
export function validateNode(
  type: string,
  params: unknown,
): { ok: true; params: Record<string, unknown> } | { ok: false; reason: string } {
  const definition = getComponent(type)
  if (!definition) return { ok: false, reason: `componente "${type}" não registrado` }
  const parsed = definition.params.safeParse(params ?? {})
  if (!parsed.success) {
    return {
      ok: false,
      reason: parsed.error.issues
        .map((i) => `${i.path.join('.') || 'params'}: ${i.message}`)
        .join('; '),
    }
  }
  return { ok: true, params: parsed.data as Record<string, unknown> }
}
