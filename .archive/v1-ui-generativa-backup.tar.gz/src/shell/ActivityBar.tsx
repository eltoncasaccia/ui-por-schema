import { uiActions, uiStore, type PanelId } from '../state/uiStore'
import { useStore } from '../state/useStore'

const ITEMS: { id: PanelId; glyph: string; label: string }[] = [
  { id: 'navigation', glyph: '☰', label: 'Navegação' },
  { id: 'pinned', glyph: '★', label: 'Views fixadas' },
]

export function ActivityBar() {
  const { activePanel, sidePanelOpen, assistantOpen, debugOpen } = useStore(uiStore)

  return (
    <nav className="activity-bar" aria-label="Barra de atividades">
      {ITEMS.map((item) => (
        <button
          key={item.id}
          className={`activity-item ${
            activePanel === item.id && sidePanelOpen ? 'is-active' : ''
          }`}
          onClick={() => uiActions.selectPanel(item.id)}
          title={item.label}
          aria-label={item.label}
          aria-pressed={activePanel === item.id && sidePanelOpen}
        >
          <span aria-hidden="true">{item.glyph}</span>
        </button>
      ))}

      <button
        className={`activity-item ${assistantOpen ? 'is-active' : ''}`}
        onClick={uiActions.toggleAssistant}
        title="Assistente"
        aria-label="Assistente"
        aria-pressed={assistantOpen}
      >
        <span aria-hidden="true">✦</span>
      </button>

      <button
        className={`activity-item activity-bottom ${debugOpen ? 'is-active' : ''}`}
        onClick={uiActions.toggleDebug}
        title="Arquitetura / Execution Trace"
        aria-label="Arquitetura"
        aria-pressed={debugOpen}
      >
        <span aria-hidden="true">⌥</span>
      </button>
    </nav>
  )
}
