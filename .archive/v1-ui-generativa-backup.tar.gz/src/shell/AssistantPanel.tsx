import { useState } from 'react'
import {
  ask,
  clearChat,
  dispatch,
  pin,
  sendToWorkspace,
} from '../application/actions'
import { CompositionView } from '../render/CompositionView'
import { viewKey } from '../schema/types'
import { configActions, configStore } from '../state/configStore'
import { sessionStore } from '../state/sessionStore'
import { useStore } from '../state/useStore'

const SUGGESTIONS = [
  'mostre a viagem 45872',
  'liste as viagens programadas',
  'quais viagens estão atrasadas',
  'como está a frota',
  'compare a viagem 45872 com a 45873',
]

export function AssistantPanel() {
  const { conversation, compositions, workspaceCompositionId, pinned } =
    useStore(sessionStore)
  const config = useStore(configStore)
  // Local UI state for the input. This is what `useState` is actually for:
  // state that no other part of the system needs to know about.
  const [draft, setDraft] = useState('')

  const submit = (text: string) => {
    setDraft('')
    void ask(text)
  }

  return (
    <div className="panel panel-assistant">
      <div className="assistant-head">
        <h2 className="panel-title">Assistente</h2>
        <div className="assistant-tools">
          <select
            className="adapter-select"
            value={config.adapterId}
            onChange={(event) =>
              configActions.setAdapter(event.target.value as 'mock' | 'claude')
            }
            aria-label="Adaptador do assistente"
          >
            <option value="mock">Mock (local)</option>
            <option value="claude" disabled={config.claudeAvailable === false}>
              {config.claudeAvailable === false
                ? 'Claude (sem API key)'
                : 'Claude (API real)'}
            </option>
          </select>
          <button
            className="ghost-button"
            onClick={clearChat}
            disabled={conversation.length === 0}
            title="Limpar conversa"
          >
            Limpar
          </button>
        </div>
      </div>

      <div className="conversation">
        {conversation.length === 0 && (
          <div className="assistant-empty">
            <p className="muted">
              O assistente não escreve código nem inventa números. Ele escolhe quais
              componentes registrados compor — e o sistema fornece os dados.
            </p>
            <ul className="suggestions">
              {SUGGESTIONS.map((suggestion) => (
                <li key={suggestion}>
                  <button className="suggestion" onClick={() => submit(suggestion)}>
                    {suggestion}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {conversation.map((message) => {
          if (message.role === 'user') {
            return (
              <div key={message.id} className="msg msg-user">
                {message.text}
              </div>
            )
          }

          const composition = message.compositionId
            ? compositions[message.compositionId]
            : undefined

          const inWorkspace =
            composition !== undefined && composition.id === workspaceCompositionId
          const isPinned =
            composition !== undefined &&
            pinned.some((entry) => entry.key === viewKey(composition.schema))

          return (
            <div key={message.id} className="msg msg-assistant">
              {message.text && <p className="msg-note">{message.text}</p>}

              {message.error ? (
                <p className="msg-error">{message.error}</p>
              ) : composition && composition.nodes.length > 0 ? (
                <div className="inline-composition">
                  <div className="inline-head">
                    <span className="inline-title">{composition.title}</span>
                    <div className="inline-actions">
                      <button
                        className={`icon-button ${isPinned ? 'is-pinned' : ''}`}
                        onClick={() => pin(composition)}
                        title={isPinned ? 'Remover dos favoritos' : 'Fixar view'}
                        aria-pressed={isPinned}
                      >
                        ★
                      </button>
                      <button
                        className="ghost-button"
                        onClick={() => sendToWorkspace(composition.id)}
                        disabled={inWorkspace}
                        title={
                          inWorkspace
                            ? 'Já está no workspace'
                            : 'Abrir esta composição no workspace'
                        }
                      >
                        {inWorkspace ? 'No workspace' : 'Enviar para workspace'}
                      </button>
                    </div>
                  </div>
                  <CompositionView composition={composition} dispatch={dispatch} />
                </div>
              ) : (
                <p className="muted">compondo…</p>
              )}
            </div>
          )
        })}
      </div>

      <form
        className="composer"
        onSubmit={(event) => {
          event.preventDefault()
          submit(draft)
        }}
      >
        <input
          className="composer-input"
          placeholder="Ask anything…"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          aria-label="Pergunta para o assistente"
        />
        <button className="composer-send" type="submit" disabled={!draft.trim()}>
          →
        </button>
      </form>
    </div>
  )
}
