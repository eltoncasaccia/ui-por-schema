/**
 * The instrument panel. This is how the POC gets judged rather than admired.
 */

import { buildCatalog } from '../registry/catalog'
import { dataStore } from '../state/dataStore'
import { sessionStore } from '../state/sessionStore'
import { traceStore, type TraceRun } from '../state/traceStore'
import { uiActions, uiStore, type DebugTab } from '../state/uiStore'
import { useStore } from '../state/useStore'

const TABS: { id: DebugTab; label: string }[] = [
  { id: 'trace', label: 'Execution Trace' },
  { id: 'schema', label: 'View Schema' },
  { id: 'catalog', label: 'Catálogo do modelo' },
  { id: 'state', label: 'Estado' },
]

export function DebugPanel() {
  const { debugTab } = useStore(uiStore)

  return (
    <aside className="debug">
      <div className="debug-tabs">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            className={`debug-tab ${debugTab === tab.id ? 'is-active' : ''}`}
            onClick={() => uiActions.setDebugTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
        <button className="debug-close" onClick={uiActions.toggleDebug} title="Fechar">
          ✕
        </button>
      </div>

      <div className="debug-body">
        {debugTab === 'trace' && <TraceTab />}
        {debugTab === 'schema' && <SchemaTab />}
        {debugTab === 'catalog' && <CatalogTab />}
        {debugTab === 'state' && <StateTab />}
      </div>
    </aside>
  )
}

function TraceTab() {
  const { runs } = useStore(traceStore)

  if (runs.length === 0) {
    return <p className="muted">Nenhuma execução ainda. Abra uma view ou pergunte algo.</p>
  }

  return (
    <div className="trace-list">
      {runs.map((run) => (
        <RunView key={run.id} run={run} />
      ))}
    </div>
  )
}

function RunView({ run }: { run: TraceRun }) {
  return (
    <section className="trace-run">
      <header className="trace-run-head">
        <span className={`source-tag source-${run.source}`}>{run.adapter}</span>
        <span className="trace-input">{run.input}</span>
        <span className="trace-times">
          {run.timeToFirstComponentMs !== undefined && (
            <span title="Tempo até o primeiro componente aparecer">
              1º componente {Math.round(run.timeToFirstComponentMs)} ms
            </span>
          )}
          {run.totalMs !== undefined && <span>total {Math.round(run.totalMs)} ms</span>}
        </span>
      </header>

      <ol className="trace-steps">
        {run.steps.map((step, index) => (
          <li key={index} className={`trace-step is-${step.status}`}>
            <span className="trace-stage">{step.stage}</span>
            <span className="trace-label">{step.label}</span>
            {step.detail && <span className="trace-detail">{step.detail}</span>}
            <span className="trace-duration">
              {step.durationMs === undefined ? '…' : `${Math.round(step.durationMs)} ms`}
            </span>
          </li>
        ))}
      </ol>
    </section>
  )
}

function SchemaTab() {
  const { compositions, workspaceCompositionId } = useStore(sessionStore)
  const composition = workspaceCompositionId ? compositions[workspaceCompositionId] : null

  if (!composition) return <p className="muted">Nenhuma composição no workspace.</p>

  return (
    <>
      <p className="debug-note">
        Isto é tudo que o assistente pode produzir. Sem JSX, sem CSS, sem dados —
        apenas nomes de componentes registrados e parâmetros validados.
      </p>
      <pre className="code">{JSON.stringify(composition.schema, null, 2)}</pre>
    </>
  )
}

function CatalogTab() {
  const catalog = buildCatalog()

  return (
    <>
      <p className="debug-note">
        Derivado do Component Registry, não escrito à mão. Registrar um componente
        já o coloca no vocabulário do modelo — não existe uma segunda lista para
        esquecer de atualizar.
      </p>
      <pre className="code">{JSON.stringify(catalog, null, 2)}</pre>
    </>
  )
}

function StateTab() {
  const data = useStore(dataStore)
  const session = useStore(sessionStore)
  const ui = useStore(uiStore)

  return (
    <div className="state-grid">
      <StateBlock
        title="Persistent — entidades"
        note="Normalizado por id. Uma viagem existe uma vez, mesmo aparecendo em três telas."
        value={{
          trips: Object.keys(data.trips),
          vehicles: Object.keys(data.vehicles),
          drivers: Object.keys(data.drivers),
          routes: Object.keys(data.routes),
          allTripIds: data.allTripIds,
          delayedTripIds: data.delayedTripIds,
          fleetCounts: data.fleetCounts,
        }}
      />
      <StateBlock
        title="Session — o que está sendo feito"
        note="Composições por id; workspace e chat apontam para a mesma, não copiam."
        value={{
          workspaceCompositionId: session.workspaceCompositionId,
          compositions: Object.fromEntries(
            Object.entries(session.compositions).map(([id, composition]) => [
              id,
              `${composition.title} · ${composition.nodes.length} nós · ${composition.source}`,
            ]),
          ),
          pinned: session.pinned,
          mensagens: session.conversation.length,
          lastIntent: session.lastIntent,
        }}
      />
      <StateBlock
        title="UI — apenas cromo"
        note="Nada aqui significa algo para o negócio."
        value={ui}
      />
    </div>
  )
}

function StateBlock({
  title,
  note,
  value,
}: {
  title: string
  note: string
  value: unknown
}) {
  return (
    <section className="state-block">
      <h4>{title}</h4>
      <p className="debug-note">{note}</p>
      <pre className="code">{JSON.stringify(value, null, 2)}</pre>
    </section>
  )
}
