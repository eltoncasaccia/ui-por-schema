import { openPreset, openTrip } from '../application/actions'
import {
  allTripsSchema,
  delayedTripsSchema,
  driversSchema,
  fleetOverviewSchema,
} from '../schema/presets'
import { STATUS_LABEL } from '../viewmodels/format'
import { dataStore } from '../state/dataStore'
import { useStore } from '../state/useStore'

const VIEWS = [
  { label: 'Panorama da frota', schema: fleetOverviewSchema },
  { label: 'Viagens em atraso', schema: delayedTripsSchema },
  { label: 'Todas as viagens', schema: allTripsSchema },
  { label: 'Motoristas', schema: driversSchema },
]

export function NavigationPanel() {
  // Reads what the store already has. No fetching from a component.
  const trips = useStore(dataStore, (state) =>
    (state.allTripIds ?? []).map((id) => state.trips[id]).filter(Boolean),
  )

  return (
    <div className="panel">
      <h2 className="panel-title">Navegação</h2>

      <section className="panel-section">
        <h3 className="panel-heading">Views</h3>
        <ul className="nav-list">
          {VIEWS.map((view) => (
            <li key={view.label}>
              <button className="nav-item" onClick={() => void openPreset(view.schema, view.label)}>
                {view.label}
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section className="panel-section">
        <h3 className="panel-heading">Viagens</h3>
        {trips.length === 0 ? (
          <p className="muted">carregando…</p>
        ) : (
          <ul className="nav-list">
            {trips.map((trip) => (
              <li key={trip.id}>
                <button className="nav-item" onClick={() => void openTrip(trip.id)}>
                  <span className="nav-item-main">{trip.id}</span>
                  <span className="nav-item-sub">
                    {trip.origin} → {trip.destination}
                  </span>
                  <span className="nav-item-tag">{STATUS_LABEL[trip.status]}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
