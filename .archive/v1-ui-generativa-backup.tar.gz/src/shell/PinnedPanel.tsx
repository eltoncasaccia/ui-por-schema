import { openPinned, unpin } from '../application/actions'
import { sessionStore } from '../state/sessionStore'
import { useStore } from '../state/useStore'
import { viewKey } from '../schema/types'

export function PinnedPanel() {
  const { pinned, compositions, workspaceCompositionId } = useStore(sessionStore)
  const current = workspaceCompositionId ? compositions[workspaceCompositionId] : undefined
  const currentKey = current ? viewKey(current.schema) : null

  return (
    <div className="panel">
      <h2 className="panel-title">Views fixadas</h2>

      {pinned.length === 0 ? (
        <p className="muted">
          Nada fixado ainda. Use ★ no cabeçalho do workspace para guardar uma
          composição e reabri-la depois.
        </p>
      ) : (
        <ul className="nav-list">
          {pinned.map((entry) => (
            <li key={entry.key} className="pin-row">
              <button
                className={`nav-item ${currentKey === entry.key ? 'is-current' : ''}`}
                onClick={() => void openPinned(entry)}
                title="Reabrir com dados atualizados"
              >
                <span className="nav-item-main">★ {entry.label}</span>
                <span className="nav-item-sub">
                  {entry.schema.components.length} componente(s) · layout{' '}
                  {entry.schema.layout}
                </span>
              </button>
              <button
                className="pin-remove"
                onClick={() => unpin(entry)}
                title="Remover dos favoritos"
                aria-label={`Remover ${entry.label} dos favoritos`}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
