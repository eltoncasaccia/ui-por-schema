import { dispatch, pin } from '../application/actions'
import { viewKey } from '../schema/types'
import { CompositionView } from '../render/CompositionView'
import { sessionStore } from '../state/sessionStore'
import { useStore } from '../state/useStore'

export function Workspace() {
  const { compositions, workspaceCompositionId, pinned } = useStore(sessionStore)
  const composition = workspaceCompositionId
    ? compositions[workspaceCompositionId]
    : undefined

  if (!composition) {
    return (
      <main className="workspace">
        <div className="workspace-empty">
          <h1>Workspace</h1>
          <p className="muted">
            Abra uma view pela navegação, ou peça ao assistente. Os dois caminhos
            produzem o mesmo tipo de schema e passam pelo mesmo pipeline.
          </p>
        </div>
      </main>
    )
  }

  // Keyed on the schema, so reopening a pinned view still shows as pinned.
  const isPinned = pinned.some((entry) => entry.key === viewKey(composition.schema))
  const ready = composition.nodes.filter((node) => node.status === 'ready').length

  return (
    <main className="workspace">
      <header className="workspace-head">
        <div>
          <h1>{composition.title}</h1>
          <p className="workspace-sub">
            <span className={`source-tag source-${composition.source}`}>
              {composition.source === 'assistant' ? 'schema do assistente' : 'schema do sistema'}
            </span>
            <span className="muted">
              {ready}/{composition.nodes.length} componentes prontos
            </span>
          </p>
        </div>
        <button
          className={`pin-button ${isPinned ? 'is-pinned' : ''}`}
          onClick={() => pin(composition)}
          title={isPinned ? 'Desafixar' : 'Fixar view'}
        >
          ★
        </button>
      </header>

      <div className="workspace-body">
        <CompositionView composition={composition} dispatch={dispatch} />
      </div>
    </main>
  )
}
