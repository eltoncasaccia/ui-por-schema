/** Which assistant backs the app, and whether the real one is reachable. */

import { createStore } from './store'

export interface ConfigState {
  adapterId: 'mock' | 'claude'
  claudeAvailable: boolean | null
}

export const configStore = createStore<ConfigState>({
  adapterId: 'mock',
  claudeAvailable: null,
})

export const configActions = {
  setAdapter(adapterId: ConfigState['adapterId']) {
    configStore.set((state) => ({ ...state, adapterId }))
  },
  setClaudeAvailable(claudeAvailable: boolean) {
    configStore.set((state) => ({ ...state, claudeAvailable }))
  },
}
