/**
 * PERSISTENT STATE — the entities themselves.
 *
 * Normalised by id, so a trip that appears in the workspace, in a chat message
 * and in a pinned view is one object, not three copies that drift apart.
 * Only the application layer writes here.
 */

import type { Driver, Route, Trip, TripTracking, Vehicle } from '../domain/types'
import { createStore } from './store'

export interface FleetCounts {
  total: number
  assigned: number
  available: number
  maintenance: number
  tripsInTransit: number
  tripsDelayed: number
}

export interface DataState {
  trips: Record<string, Trip>
  vehicles: Record<string, Vehicle>
  drivers: Record<string, Driver>
  routes: Record<string, Route>
  /** Query results stored as id lists, never as duplicated entities. */
  allTripIds: string[] | null
  delayedTripIds: string[] | null
  allVehicleIds: string[] | null
  allDriverIds: string[] | null
  fleetCounts: FleetCounts | null
}

const empty: DataState = {
  trips: {},
  vehicles: {},
  drivers: {},
  routes: {},
  allTripIds: null,
  delayedTripIds: null,
  allVehicleIds: null,
  allDriverIds: null,
  fleetCounts: null,
}

export const dataStore = createStore<DataState>(empty)

function index<T extends { id: string }>(items: T[]): Record<string, T> {
  return Object.fromEntries(items.map((item) => [item.id, item]))
}

export const dataActions = {
  ingestTracking(tracking: TripTracking) {
    dataStore.set((state) => ({
      ...state,
      trips: { ...state.trips, [tracking.trip.id]: tracking.trip },
      vehicles: tracking.vehicle
        ? { ...state.vehicles, [tracking.vehicle.id]: tracking.vehicle }
        : state.vehicles,
      drivers: tracking.driver
        ? { ...state.drivers, [tracking.driver.id]: tracking.driver }
        : state.drivers,
      routes: { ...state.routes, [tracking.route.id]: tracking.route },
    }))
  },

  ingestTrips(trips: Trip[], list: 'allTripIds' | 'delayedTripIds') {
    dataStore.set((state) => ({
      ...state,
      trips: { ...state.trips, ...index(trips) },
      [list]: trips.map((t) => t.id),
    }))
  },

  ingestVehicles(vehicles: Vehicle[]) {
    dataStore.set((state) => ({
      ...state,
      vehicles: { ...state.vehicles, ...index(vehicles) },
      allVehicleIds: vehicles.map((v) => v.id),
    }))
  },

  ingestDrivers(drivers: Driver[]) {
    dataStore.set((state) => ({
      ...state,
      drivers: { ...state.drivers, ...index(drivers) },
      allDriverIds: drivers.map((d) => d.id),
    }))
  },

  ingestRoute(route: Route) {
    dataStore.set((state) => ({
      ...state,
      routes: { ...state.routes, [route.id]: route },
    }))
  },

  ingestFleetCounts(counts: FleetCounts) {
    dataStore.set((state) => ({ ...state, fleetCounts: counts }))
  },
}
