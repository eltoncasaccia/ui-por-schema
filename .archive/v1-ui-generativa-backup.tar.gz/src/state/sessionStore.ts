/**
 * SESSION STATE — what the user is currently doing.
 *
 * Compositions are kept in a keyed map and referenced by id. Promoting a chat
 * answer into the workspace points at the same composition; it does not copy
 * it. Pinning does the same. One composition, many places showing it.
 */

import type { Composition, ViewSchema } from '../schema/types'
import { viewKey } from '../schema/types'
import { createStore } from './store'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  text: string
  /** Set when the assistant answered with a rendered composition. */
  compositionId?: string
  /** Streaming assistants fill this in progressively. */
  streaming?: boolean
  error?: string
}

export interface PinnedView {
  /** Identity of the VIEW, not of the render that produced it. */
  key: string
  label: string
  /** Kept so reopening a pin re-runs the schema against fresh data. */
  schema: ViewSchema
}

export interface SessionState {
  compositions: Record<string, Composition>
  workspaceCompositionId: string | null
  conversation: ChatMessage[]
  pinned: PinnedView[]
  /** Last parsed user intent, shown in the Debug panel. */
  lastIntent: unknown | null
}

export const sessionStore = createStore<SessionState>({
  compositions: {},
  workspaceCompositionId: null,
  conversation: [],
  pinned: [],
  lastIntent: null,
})

export const sessionActions = {
  putComposition(composition: Composition) {
    sessionStore.set((state) => ({
      ...state,
      compositions: { ...state.compositions, [composition.id]: composition },
    }))
  },

  updateComposition(compositionId: string, patch: Partial<Composition>) {
    sessionStore.set((state) => {
      const composition = state.compositions[compositionId]
      if (!composition) return state
      return {
        ...state,
        compositions: {
          ...state.compositions,
          [compositionId]: { ...composition, ...patch },
        },
      }
    })
  },

  patchNode(compositionId: string, index: number, patch: Partial<Composition['nodes'][number]>) {
    sessionStore.set((state) => {
      const composition = state.compositions[compositionId]
      if (!composition) return state
      const nodes = composition.nodes.map((node, i) =>
        i === index ? { ...node, ...patch } : node,
      )
      return {
        ...state,
        compositions: {
          ...state.compositions,
          [compositionId]: { ...composition, nodes },
        },
      }
    })
  },

  /** Append nodes as a streaming assistant emits them. */
  appendNode(compositionId: string, node: Composition['nodes'][number]) {
    sessionStore.set((state) => {
      const composition = state.compositions[compositionId]
      if (!composition) return state
      return {
        ...state,
        compositions: {
          ...state.compositions,
          [compositionId]: { ...composition, nodes: [...composition.nodes, node] },
        },
      }
    })
  },

  setCompositionTitle(compositionId: string, title: string) {
    sessionStore.set((state) => {
      const composition = state.compositions[compositionId]
      if (!composition) return state
      return {
        ...state,
        compositions: {
          ...state.compositions,
          [compositionId]: { ...composition, title },
        },
      }
    })
  },

  showInWorkspace(compositionId: string) {
    sessionStore.set((state) => ({ ...state, workspaceCompositionId: compositionId }))
  },

  addMessage(message: ChatMessage) {
    sessionStore.set((state) => ({
      ...state,
      conversation: [...state.conversation, message],
    }))
  },

  patchMessage(id: string, patch: Partial<ChatMessage>) {
    sessionStore.set((state) => ({
      ...state,
      conversation: state.conversation.map((m) =>
        m.id === id ? { ...m, ...patch } : m,
      ),
    }))
  },

  togglePin(schema: ViewSchema, label: string) {
    const key = viewKey(schema)
    sessionStore.set((state) => {
      const exists = state.pinned.some((pin) => pin.key === key)
      return {
        ...state,
        pinned: exists
          ? state.pinned.filter((pin) => pin.key !== key)
          : [...state.pinned, { key, label, schema }],
      }
    })
  },

  /**
   * Clears the conversation and drops the compositions only it referenced.
   * Anything promoted to the workspace stays — clearing the chat is not
   * supposed to blank the screen behind it.
   */
  clearConversation() {
    sessionStore.set((state) => {
      const keep = new Set<string>()
      if (state.workspaceCompositionId) keep.add(state.workspaceCompositionId)

      return {
        ...state,
        conversation: [],
        compositions: Object.fromEntries(
          Object.entries(state.compositions).filter(([id]) => keep.has(id)),
        ),
      }
    })
  },

  setIntent(intent: unknown) {
    sessionStore.set((state) => ({ ...state, lastIntent: intent }))
  },
}
