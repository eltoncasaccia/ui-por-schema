/**
 * A minimal observable store. Deliberately framework-free — this file does not
 * import React, and the app's data flow works without it.
 *
 * This is what replaces `useEffect` for orchestration: state lives outside the
 * render cycle, and updates are pushed into it by user intent, not pulled by a
 * component that happens to have mounted.
 */

export type Listener = () => void

export interface Store<T> {
  getSnapshot: () => T
  subscribe: (listener: Listener) => () => void
  set: (updater: T | ((prev: T) => T)) => void
}

export function createStore<T>(initial: T): Store<T> {
  let state = initial
  const listeners = new Set<Listener>()

  return {
    getSnapshot: () => state,
    subscribe(listener) {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },
    set(updater) {
      const next =
        typeof updater === 'function'
          ? (updater as (prev: T) => T)(state)
          : updater
      if (Object.is(next, state)) return
      state = next
      listeners.forEach((l) => l())
    },
  }
}

/**
 * Cancellation for async work, replacing what `useEffect`'s cleanup would do.
 *
 * Without effects there is nothing to "unmount", so a superseded request would
 * happily overwrite a newer one: open trip A, open trip B, and A's slower
 * response lands last. Each slot keeps a monotonic token; a result whose token
 * is stale is dropped.
 */
const tokens = new Map<string, number>()

export function claimSlot(slot: string): () => boolean {
  const token = (tokens.get(slot) ?? 0) + 1
  tokens.set(slot, token)
  return () => tokens.get(slot) === token
}
