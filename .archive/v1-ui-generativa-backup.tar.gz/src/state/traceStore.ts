/**
 * The measuring instrument.
 *
 * Every run records each stage and how long it took. This is how the POC gets
 * judged: if the pipeline is slow or the model emits invalid schemas, it shows
 * up here rather than in a vibe.
 */

import { createStore } from './store'

export type TraceStage =
  | 'user_intent'
  | 'assistant'
  | 'schema_received'
  | 'validation'
  | 'data_load'
  | 'render'

export type TraceStatus = 'running' | 'ok' | 'error'

export interface TraceStep {
  stage: TraceStage
  label: string
  status: TraceStatus
  startedAt: number
  durationMs?: number
  detail?: string
}

export interface TraceRun {
  id: string
  input: string
  source: 'navigation' | 'assistant'
  adapter: string
  startedAt: number
  steps: TraceStep[]
  totalMs?: number
  /** Time until the first component became visible. The number that matters. */
  timeToFirstComponentMs?: number
}

export interface TraceState {
  runs: TraceRun[]
}

export const traceStore = createStore<TraceState>({ runs: [] })

const MAX_RUNS = 20

export function startRun(
  id: string,
  input: string,
  source: TraceRun['source'],
  adapter: string,
): void {
  traceStore.set((state) => ({
    runs: [
      { id, input, source, adapter, startedAt: performance.now(), steps: [] },
      ...state.runs,
    ].slice(0, MAX_RUNS),
  }))
}

function updateRun(id: string, update: (run: TraceRun) => TraceRun): void {
  traceStore.set((state) => ({
    runs: state.runs.map((run) => (run.id === id ? update(run) : run)),
  }))
}

export function step(
  runId: string,
  stage: TraceStage,
  label: string,
  detail?: string,
): (status: TraceStatus, detail?: string) => void {
  const startedAt = performance.now()
  updateRun(runId, (run) => ({
    ...run,
    steps: [...run.steps, { stage, label, status: 'running', startedAt, detail }],
  }))

  return (status, endDetail) => {
    const durationMs = performance.now() - startedAt
    updateRun(runId, (run) => ({
      ...run,
      steps: run.steps.map((s) =>
        s.stage === stage && s.startedAt === startedAt
          ? { ...s, status, durationMs, detail: endDetail ?? s.detail }
          : s,
      ),
    }))
  }
}

export function markFirstComponent(runId: string): void {
  updateRun(runId, (run) =>
    run.timeToFirstComponentMs === undefined
      ? { ...run, timeToFirstComponentMs: performance.now() - run.startedAt }
      : run,
  )
}

export function finishRun(runId: string): void {
  updateRun(runId, (run) => ({ ...run, totalMs: performance.now() - run.startedAt }))
}
