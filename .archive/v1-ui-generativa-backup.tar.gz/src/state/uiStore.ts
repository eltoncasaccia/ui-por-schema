/**
 * UI STATE — pure chrome. Nothing here survives a reload, and nothing here
 * means anything to the business. Kept apart from session state on purpose:
 * "which panel is open" and "which trip is being investigated" are not the
 * same kind of fact.
 */

import { createStore } from './store'

/** Left dock. The assistant is no longer one of these — it has its own side. */
export type PanelId = 'navigation' | 'pinned'
export type DebugTab = 'trace' | 'schema' | 'catalog' | 'state'

export interface UiState {
  activePanel: PanelId
  sidePanelOpen: boolean
  /** The assistant docks on the right, beside the workspace rather than over it. */
  assistantOpen: boolean
  debugOpen: boolean
  debugTab: DebugTab
}

export const uiStore = createStore<UiState>({
  activePanel: 'navigation',
  sidePanelOpen: true,
  assistantOpen: true,
  debugOpen: false,
  debugTab: 'trace',
})

export const uiActions = {
  /** Activity-bar behaviour: clicking the open panel collapses it. */
  selectPanel(panel: UiState['activePanel']) {
    uiStore.set((state) =>
      state.activePanel === panel && state.sidePanelOpen
        ? { ...state, sidePanelOpen: false }
        : { ...state, activePanel: panel, sidePanelOpen: true },
    )
  },
  /**
   * Reveals a panel without toggling. Used when the application needs a panel
   * visible — collapsing it there would be the opposite of the intent.
   */
  openPanel(panel: UiState['activePanel']) {
    uiStore.set((state) => ({ ...state, activePanel: panel, sidePanelOpen: true }))
  },
  toggleAssistant() {
    uiStore.set((state) => ({ ...state, assistantOpen: !state.assistantOpen }))
  },
  openAssistant() {
    uiStore.set((state) => ({ ...state, assistantOpen: true }))
  },
  toggleDebug() {
    uiStore.set((state) => ({ ...state, debugOpen: !state.debugOpen }))
  },
  setDebugTab(tab: UiState['debugTab']) {
    uiStore.set((state) => ({ ...state, debugOpen: true, debugTab: tab }))
  },
}
