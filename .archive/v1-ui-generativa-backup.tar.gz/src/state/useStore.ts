/**
 * The one place React is allowed to learn about application state.
 *
 * `useSyncExternalStore` subscribes to a store that already exists, instead of
 * a `useEffect` that fetches on mount. Components read; they never load.
 */

import { useCallback, useRef, useSyncExternalStore } from 'react'
import type { Store } from './store'

export function useStore<T, S = T>(
  store: Store<T>,
  selector: (state: T) => S = (state) => state as unknown as S,
): S {
  const lastSnapshot = useRef<T | undefined>(undefined)
  const lastSelected = useRef<S | undefined>(undefined)
  const initialised = useRef(false)

  // `useSyncExternalStore` requires a getSnapshot that returns a stable value
  // while nothing changed. We recompute the selection only when the underlying
  // store snapshot identity changes, which makes the result referentially safe.
  const getSelection = useCallback(() => {
    const snapshot = store.getSnapshot()
    if (!initialised.current || snapshot !== lastSnapshot.current) {
      lastSnapshot.current = snapshot
      lastSelected.current = selector(snapshot)
      initialised.current = true
    }
    return lastSelected.current as S
  }, [store, selector])

  return useSyncExternalStore(store.subscribe, getSelection, getSelection)
}
