/** View models for fleet-wide and tabular views. Pure projections. */

import { delayMinutes, isDelayed, progressPct } from '../domain/rules'
import type { DataState } from '../state/dataStore'
import type { UiAction } from '../schema/actions'
import { STATUS_LABEL, delayLabel, kg, km, time, type Tone } from './format'

export const METRICS = [
  'fleet_total',
  'fleet_available',
  'fleet_assigned',
  'fleet_maintenance',
  'trips_in_transit',
  'trips_delayed',
] as const

export type MetricId = (typeof METRICS)[number]

export interface MetricVM {
  label: string
  value: string
  hint: string
  tone: Tone
}

/**
 * Note the shape of this: the model chooses WHICH metric, never the number.
 * If `metric_card` accepted a literal value, a hallucinated figure would render
 * as confidently as a real one.
 */
export function metricVM(state: DataState, metric: MetricId): MetricVM | null {
  const counts = state.fleetCounts
  if (!counts) return null

  switch (metric) {
    case 'fleet_total':
      return { label: 'Veículos na frota', value: String(counts.total), hint: 'total cadastrado', tone: 'neutral' }
    case 'fleet_available':
      return { label: 'Disponíveis', value: String(counts.available), hint: 'prontos para alocação', tone: 'good' }
    case 'fleet_assigned':
      return { label: 'Alocados', value: String(counts.assigned), hint: 'em viagem ou reservados', tone: 'neutral' }
    case 'fleet_maintenance':
      return { label: 'Em manutenção', value: String(counts.maintenance), hint: 'indisponíveis', tone: 'warn' }
    case 'trips_in_transit':
      return { label: 'Viagens em trânsito', value: String(counts.tripsInTransit), hint: 'agora', tone: 'good' }
    case 'trips_delayed':
      return {
        label: 'Viagens atrasadas',
        value: String(counts.tripsDelayed),
        hint: 'acima da tolerância de 10 min',
        tone: counts.tripsDelayed > 0 ? 'bad' : 'good',
      }
  }
}

export const TABLE_ENTITIES = ['trips', 'vehicles', 'drivers'] as const

/**
 * Filters are declared per entity, and the union of them is what the model may
 * say. Getting this list wrong is not a cosmetic problem: a status the
 * catalogue does not name is a question the assistant cannot ask, and it will
 * silently answer a broader one instead.
 */
export const TRIP_FILTERS = [
  'all',
  'delayed',
  'scheduled',
  'loading',
  'in_transit',
  'delivered',
  'cancelled',
] as const

export const VEHICLE_FILTERS = ['all', 'available', 'assigned', 'maintenance'] as const

export const DRIVER_FILTERS = ['all', 'over_shift'] as const

export const TABLE_FILTERS = [
  ...new Set([...TRIP_FILTERS, ...VEHICLE_FILTERS, ...DRIVER_FILTERS]),
] as const

export type TableEntity = (typeof TABLE_ENTITIES)[number]
export type TableFilter = (typeof TABLE_FILTERS)[number]

/** Which filters are meaningful for which entity. Enforced at the gate. */
export const FILTERS_BY_ENTITY: Record<TableEntity, readonly string[]> = {
  trips: TRIP_FILTERS,
  vehicles: VEHICLE_FILTERS,
  drivers: DRIVER_FILTERS,
}

const FILTER_LABEL: Record<string, string> = {
  all: '',
  delayed: 'em atraso',
  scheduled: 'programada(s)',
  loading: 'em carregamento',
  in_transit: 'em trânsito',
  delivered: 'entregue(s)',
  cancelled: 'cancelada(s)',
  available: 'disponível(is)',
  assigned: 'alocado(s)',
  maintenance: 'em manutenção',
  over_shift: 'com jornada excedida',
}

export interface TableCell {
  text: string
  tone?: Tone
}

export interface TableVM {
  caption: string
  columns: string[]
  rows: { key: string; cells: TableCell[]; action?: UiAction }[]
}

export function tableVM(
  state: DataState,
  entity: TableEntity,
  filter: TableFilter,
): TableVM | null {
  if (entity === 'trips') return tripsTable(state, filter)
  if (entity === 'vehicles') return vehiclesTable(state, filter)
  return driversTable(state, filter)
}

function tripsTable(state: DataState, filter: TableFilter): TableVM | null {
  const ids = filter === 'delayed' ? state.delayedTripIds : state.allTripIds
  if (!ids) return null

  const all = ids.map((id) => state.trips[id]).filter(Boolean)

  // 'delayed' comes from the domain rule; every other filter is a status.
  const trips =
    filter === 'all' || filter === 'delayed'
      ? all
      : all.filter((trip) => trip.status === filter)

  const suffix = FILTER_LABEL[filter] ? ` ${FILTER_LABEL[filter]}` : ''

  return {
    caption: `${trips.length} viagem(ns)${suffix}`,
    columns: ['Viagem', 'Trecho', 'Status', 'ETA', 'Situação', 'Progresso'],
    rows: trips.map((trip) => {
      const delay = delayLabel(delayMinutes(trip))
      return {
        key: trip.id,
        action: { type: 'open_trip', tripId: trip.id } as UiAction,
        cells: [
          { text: trip.id },
          { text: `${trip.origin} → ${trip.destination}` },
          { text: STATUS_LABEL[trip.status] },
          { text: time(trip.etaCurrent) },
          { text: delay.text, tone: isDelayed(trip) ? 'bad' : delay.tone },
          { text: `${progressPct(trip)}%` },
        ],
      }
    }),
  }
}

function vehiclesTable(state: DataState, filter: TableFilter): TableVM | null {
  if (!state.allVehicleIds) return null
  const vehicles = state.allVehicleIds
    .map((id) => state.vehicles[id])
    .filter(Boolean)
    .filter((v) => (filter === 'all' ? true : v.status === filter))

  const tone = { available: 'good', assigned: 'neutral', maintenance: 'warn' } as const
  const label = { available: 'Disponível', assigned: 'Alocado', maintenance: 'Manutenção' }

  const suffix = FILTER_LABEL[filter] ? ` ${FILTER_LABEL[filter]}` : ''

  return {
    caption: `${vehicles.length} veículo(s)${suffix}`,
    columns: ['Placa', 'Modelo', 'Capacidade', 'Odômetro', 'Status'],
    rows: vehicles.map((v) => ({
      key: v.id,
      cells: [
        { text: v.plate },
        { text: v.model },
        { text: kg(v.capacityKg) },
        { text: km(v.odometerKm) },
        { text: label[v.status], tone: tone[v.status] },
      ],
    })),
  }
}

function driversTable(state: DataState, filter: TableFilter): TableVM | null {
  if (!state.allDriverIds) return null
  const all = state.allDriverIds.map((id) => state.drivers[id]).filter(Boolean)
  const drivers = filter === 'over_shift' ? all.filter((d) => d.shiftHours >= 8) : all
  const suffix = FILTER_LABEL[filter] ? ` ${FILTER_LABEL[filter]}` : ''

  return {
    caption: `${drivers.length} motorista(s)${suffix}`,
    columns: ['Nome', 'CNH', 'Telefone', 'Jornada'],
    rows: drivers.map((d) => ({
      key: d.id,
      cells: [
        { text: d.name },
        { text: d.license },
        { text: d.phone },
        { text: `${d.shiftHours} h`, tone: d.shiftHours >= 8 ? 'bad' : 'neutral' },
      ],
    })),
  }
}
