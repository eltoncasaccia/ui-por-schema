/** Presentation formatting. Pure, and deliberately outside the components. */

import type { TripStatus } from '../domain/types'

export function time(iso: string): string {
  return new Date(iso).toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function km(value: number): string {
  return `${value.toLocaleString('pt-BR')} km`
}

export function kg(value: number): string {
  return `${value.toLocaleString('pt-BR')} kg`
}

export type Tone = 'neutral' | 'good' | 'warn' | 'bad'

export const STATUS_LABEL: Record<TripStatus, string> = {
  scheduled: 'Programada',
  loading: 'Em carregamento',
  in_transit: 'Em trânsito',
  delivered: 'Entregue',
  cancelled: 'Cancelada',
}

export const STATUS_TONE: Record<TripStatus, Tone> = {
  scheduled: 'neutral',
  loading: 'warn',
  in_transit: 'good',
  delivered: 'good',
  cancelled: 'bad',
}

export function delayLabel(minutes: number): { text: string; tone: Tone } {
  if (minutes > 10) return { text: `${minutes} min de atraso`, tone: 'bad' }
  if (minutes > 0) return { text: `${minutes} min acima do plano`, tone: 'warn' }
  if (minutes < 0) return { text: `${Math.abs(minutes)} min adiantada`, tone: 'good' }
  return { text: 'No horário', tone: 'good' }
}
