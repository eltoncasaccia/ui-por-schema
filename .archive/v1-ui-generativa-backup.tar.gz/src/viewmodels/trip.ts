/**
 * View models: domain shapes projected into what a screen needs.
 *
 * Derived, never stored. The entities stay normalised in the data store; these
 * functions are pure and run during render.
 */

import { delayMinutes, isDelayed, progressPct, routeDeviation } from '../domain/rules'
import type { TripTracking } from '../domain/types'
import type { DataState } from '../state/dataStore'
import { STATUS_LABEL, STATUS_TONE, delayLabel, km, time, type Tone } from './format'

/** Re-joins a trip with its relations from normalised state. */
export function selectTracking(state: DataState, tripId: string): TripTracking | null {
  const trip = state.trips[tripId]
  if (!trip) return null
  const route = state.routes[trip.routeId]
  if (!route) return null
  return {
    trip,
    vehicle: trip.vehicleId ? (state.vehicles[trip.vehicleId] ?? null) : null,
    driver: trip.driverId ? (state.drivers[trip.driverId] ?? null) : null,
    route,
  }
}

export interface TripSummaryVM {
  id: string
  lane: string
  statusLabel: string
  statusTone: Tone
  eta: string
  etaPlanned: string
  delay: { text: string; tone: Tone }
  vehicle: string
  driver: string
  cargo: string
  distance: string
  covered: string
  progress: number
  delayed: boolean
}

export function tripSummaryVM(tracking: TripTracking): TripSummaryVM {
  const { trip, vehicle, driver } = tracking
  return {
    id: trip.id,
    lane: `${trip.origin} → ${trip.destination}`,
    statusLabel: STATUS_LABEL[trip.status],
    statusTone: STATUS_TONE[trip.status],
    eta: time(trip.etaCurrent),
    etaPlanned: time(trip.etaPlanned),
    delay: delayLabel(delayMinutes(trip)),
    vehicle: vehicle ? `${vehicle.plate} · ${vehicle.model}` : 'Sem veículo',
    driver: driver ? driver.name : 'Sem motorista',
    cargo: trip.cargo,
    distance: km(trip.distanceKm),
    covered: km(trip.distanceCoveredKm),
    progress: progressPct(trip),
    delayed: isDelayed(trip),
  }
}

export interface TimelineVM {
  tripId: string
  lane: string
  events: { time: string; label: string; kind: 'done' | 'current' | 'pending' }[]
}

export function tripTimelineVM(tracking: TripTracking): TimelineVM {
  return {
    tripId: tracking.trip.id,
    lane: `${tracking.trip.origin} → ${tracking.trip.destination}`,
    events: tracking.trip.events.map((event) => ({
      time: time(event.at),
      label: event.label,
      kind: event.kind,
    })),
  }
}

export interface MapVM {
  tripId: string
  routeName: string
  progress: number
  waypoints: { name: string; x: number; y: number; reached: boolean; at: string }[]
  position: { x: number; y: number } | null
}

export function tripMapVM(tracking: TripTracking): MapVM {
  const { trip, route } = tracking
  const progress = progressPct(trip)
  const reachedCount = trip.events.filter((e) => e.kind === 'done').length

  const waypoints = route.waypoints.map((wp, i) => ({
    name: wp.name,
    x: wp.x,
    y: wp.y,
    reached: i < reachedCount,
    at: time(wp.plannedAt),
  }))

  // Place the vehicle along the polyline at `progress` of its total length.
  const position = interpolate(route.waypoints, progress / 100)

  return { tripId: trip.id, routeName: route.name, progress, waypoints, position }
}

function interpolate(
  points: { x: number; y: number }[],
  fraction: number,
): { x: number; y: number } | null {
  if (points.length < 2) return null
  const lengths: number[] = []
  let total = 0
  for (let i = 1; i < points.length; i++) {
    const d = Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y)
    lengths.push(d)
    total += d
  }
  let target = total * Math.max(0, Math.min(1, fraction))
  for (let i = 0; i < lengths.length; i++) {
    if (target <= lengths[i]) {
      const ratio = lengths[i] === 0 ? 0 : target / lengths[i]
      return {
        x: points[i].x + (points[i + 1].x - points[i].x) * ratio,
        y: points[i].y + (points[i + 1].y - points[i].y) * ratio,
      }
    }
    target -= lengths[i]
  }
  return points[points.length - 1]
}

export interface RoutePlanVM {
  tripId: string
  routeName: string
  plannedDistance: string
  actualDistance: string
  rows: {
    name: string
    plannedAt: string
    actualAt: string | null
    driftMin: number | null
    reached: boolean
  }[]
}

export function routePlanVM(tracking: TripTracking): RoutePlanVM {
  return {
    tripId: tracking.trip.id,
    routeName: tracking.route.name,
    plannedDistance: km(tracking.route.plannedDistanceKm),
    actualDistance: km(tracking.trip.distanceKm),
    rows: routeDeviation(tracking).map((row) => ({
      name: row.name,
      plannedAt: time(row.plannedAt),
      actualAt: row.actualAt ? time(row.actualAt) : null,
      driftMin: row.driftMin,
      reached: row.reached,
    })),
  }
}
