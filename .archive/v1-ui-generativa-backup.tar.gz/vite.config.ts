import { defineConfig, loadEnv, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import { assistantMiddleware } from './server/assistant.js'

/**
 * The real-model path is a dev-server middleware rather than a separate
 * process, so the POC is still one command. Without a key it simply reports
 * itself unavailable and the UI stays on the mock adapter.
 */
function assistantPlugin(env: Record<string, string>): Plugin {
  return {
    name: 'awa-assistant',
    async configureServer(server) {
      // Imported lazily so the browser bundle never pulls in the catalogue
      // builder or the SDK.
      const { catalogPrompt } = await server.ssrLoadModule('/src/registry/catalog.ts')
      const { componentIds } = await server.ssrLoadModule('/src/registry/registry.ts')

      server.middlewares.use(
        assistantMiddleware({
          apiKey: env.ANTHROPIC_API_KEY,
          model: env.ANTHROPIC_MODEL,
          catalog: catalogPrompt(),
          componentIds,
        }),
      )
    },
  }
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  return { plugins: [react(), assistantPlugin(env)] }
})
